These are DLLs from the current version of Unity.  They are used by the
History Generator.

They are updated manually by editing the contents of this builds.zip.
