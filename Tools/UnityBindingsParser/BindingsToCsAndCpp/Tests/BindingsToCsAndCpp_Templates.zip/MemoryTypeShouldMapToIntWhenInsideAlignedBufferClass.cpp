
#include "UnityPrefix.h"
SCRIPT_BINDINGS_EXPORT_DECL
void* SCRIPT_CALL_CONVENTION AlignedBuffer_CUSTOM_AllocBuffer(ReadOnlyScriptingObjectOfType<AlignedBuffer> self, int size, Memory mem, int alignmem)
{
	SCRIPTINGAPI_STACK_CHECK(AllocBuffer)
	SCRIPTINGAPI_THREAD_CHECK(AllocBuffer)
	
			return new char[size];
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_AlignedBuffer_AllocBuffer()
{
	mono_add_internal_call( "UnityEngine.AlignedBuffer::AllocBuffer" , (gpointer)& AlignedBuffer_CUSTOM_AllocBuffer );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_MemoryTypeShouldMapToIntWhenInsideAlignedBufferClass_IcallNames [] =
{
	"UnityEngine.AlignedBuffer::AllocBuffer",	// -> AlignedBuffer_CUSTOM_AllocBuffer
	NULL
};

static const void* s_MemoryTypeShouldMapToIntWhenInsideAlignedBufferClass_IcallFuncs [] =
{
	(const void*)&AlignedBuffer_CUSTOM_AllocBuffer        ,	//  <- UnityEngine.AlignedBuffer::AllocBuffer
	NULL
};

void ExportMemoryTypeShouldMapToIntWhenInsideAlignedBufferClassBindings();
void ExportMemoryTypeShouldMapToIntWhenInsideAlignedBufferClassBindings()
{
	for (int i = 0; s_MemoryTypeShouldMapToIntWhenInsideAlignedBufferClass_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_MemoryTypeShouldMapToIntWhenInsideAlignedBufferClass_IcallNames [i], s_MemoryTypeShouldMapToIntWhenInsideAlignedBufferClass_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportMemoryTypeShouldMapToIntWhenInsideAlignedBufferClassBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(AlignedBuffer_CUSTOM_AllocBuffer);	//  <- UnityEngine.AlignedBuffer::AllocBuffer
}

#endif
