using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void Apply ( [uei.DefaultValue("true")] bool updateMipmaps, [uei.DefaultValue("false")]  bool makeNoLongerReadable) ;

	[uei.ExcludeFromDocs]
	public void Apply (bool updateMipmaps) {
		bool makeNoLongerReadable=false;
		Apply ( updateMipmaps, makeNoLongerReadable );
	}

	[uei.ExcludeFromDocs]
	public void Apply () {
		bool makeNoLongerReadable=false;
		bool updateMipmaps=true;
		Apply ( updateMipmaps, makeNoLongerReadable );
	}

}

