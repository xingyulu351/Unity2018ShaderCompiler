using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;

namespace UnityEngine
{


public sealed partial class UnityScene
{
#if UNITY_EDITOR
	public extern  bool IsDirty
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

#endif
}

public sealed partial class SceneManager
{
}


}  
