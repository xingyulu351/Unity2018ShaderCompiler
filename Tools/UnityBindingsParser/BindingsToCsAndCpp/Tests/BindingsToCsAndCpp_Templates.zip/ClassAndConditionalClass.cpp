SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION Camera_CUSTOM_SetParameter(ReadOnlyScriptingObjectOfType<Camera> self)
{
	SCRIPTINGAPI_STACK_CHECK(SetParameter)
	SCRIPTINGAPI_THREAD_CHECK(SetParameter)
	
			a++;
		
}

#if UNITY_EDITOR
SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION HumanTrait_Get_Custom_PropMuscleCount()
{
	SCRIPTINGAPI_STACK_CHECK(get_MuscleCount)
	SCRIPTINGAPI_THREAD_CHECK(get_MuscleCount)
	return HumanTrait::MuscleCount;
}

#endif
#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_SetParameter()
{
	mono_add_internal_call( "UnityEngine.Camera::SetParameter" , (gpointer)& Camera_CUSTOM_SetParameter );
}

#if UNITY_EDITOR
void Register_UnityEngine_HumanTrait_get_MuscleCount()
{
	mono_add_internal_call( "UnityEngine.HumanTrait::get_MuscleCount" , (gpointer)& HumanTrait_Get_Custom_PropMuscleCount );
}

#endif
#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_ClassAndConditionalClass_IcallNames [] =
{
	"UnityEngine.Camera::SetParameter"      ,	// -> Camera_CUSTOM_SetParameter
#if UNITY_EDITOR
	"UnityEngine.HumanTrait::get_MuscleCount",	// -> HumanTrait_Get_Custom_PropMuscleCount
#endif
	NULL
};

static const void* s_ClassAndConditionalClass_IcallFuncs [] =
{
	(const void*)&Camera_CUSTOM_SetParameter              ,	//  <- UnityEngine.Camera::SetParameter
#if UNITY_EDITOR
	(const void*)&HumanTrait_Get_Custom_PropMuscleCount   ,	//  <- UnityEngine.HumanTrait::get_MuscleCount
#endif
	NULL
};

void ExportClassAndConditionalClassBindings();
void ExportClassAndConditionalClassBindings()
{
	for (int i = 0; s_ClassAndConditionalClass_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_ClassAndConditionalClass_IcallNames [i], s_ClassAndConditionalClass_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportClassAndConditionalClassBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_CUSTOM_SetParameter);	//  <- UnityEngine.Camera::SetParameter
#if UNITY_EDITOR
	SET_METRO_BINDING(HumanTrait_Get_Custom_PropMuscleCount);	//  <- UnityEngine.HumanTrait::get_MuscleCount
#endif
}

#endif
