using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class TerrainRenderer
{
	
	#if !UNITY_WEBGL
	[uei.ExcludeFromDocs]
public static string EscapeURL (string s) {
	Encoding e=System.Text.Encoding.UTF8;
	return EscapeURL ( s, e );
}

public static string EscapeURL(string s, [uei.DefaultValue("System.Text.Encoding.UTF8")]  Encoding e) {
		a++;
	}

	#endif
}

