using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEditor
{
public sealed partial class MyClass
{
	public void EnsureQuaternionContinuity () {
		INTERNAL_CALL_EnsureQuaternionContinuity ( this );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_EnsureQuaternionContinuity (MyClass self);
}

