using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class TerrainRenderer
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void SetData (float[] data, int offsetSamples) ;

#if ENABLE_AUDIO_FMOD
	
	public static AudioClip Create(string name, int lengthSamples, int channels, int frequency, bool _3D, bool stream)
	{
		AudioClip clip = Create (name, lengthSamples, channels, frequency, _3D, stream, null, null);
		return clip;
	}
#endif
	
	public static AudioClip Create()
	{
		return null;
	}
}

