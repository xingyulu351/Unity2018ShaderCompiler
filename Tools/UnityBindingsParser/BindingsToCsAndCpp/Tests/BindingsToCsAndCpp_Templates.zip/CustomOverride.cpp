SCRIPT_BINDINGS_EXPORT_DECL
ScriptingStringPtr SCRIPT_CALL_CONVENTION TestClass_CUSTOM_ToString(ReadOnlyScriptingObjectOfType<TestClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(ToString)
	SCRIPTINGAPI_THREAD_CHECK(ToString)
	
			return CreateScriptingString(GetSafeString(BaseObject, UnityObjectToString (self)));
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_TestClass_ToString()
{
	mono_add_internal_call( "UnityEngine.TestClass::ToString" , (gpointer)& TestClass_CUSTOM_ToString );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomOverride_IcallNames [] =
{
	"UnityEngine.TestClass::ToString"       ,	// -> TestClass_CUSTOM_ToString
	NULL
};

static const void* s_CustomOverride_IcallFuncs [] =
{
	(const void*)&TestClass_CUSTOM_ToString               ,	//  <- UnityEngine.TestClass::ToString
	NULL
};

void ExportCustomOverrideBindings();
void ExportCustomOverrideBindings()
{
	for (int i = 0; s_CustomOverride_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomOverride_IcallNames [i], s_CustomOverride_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomOverrideBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(TestClass_CUSTOM_ToString);	//  <- UnityEngine.TestClass::ToString
}

#endif
