using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	public static void Custom (Vector3 start, Vector3 end, [uei.DefaultValue("Color.white")]  Color color , [uei.DefaultValue("0.0f")]  float duration , [uei.DefaultValue("true")]  bool depthTest ) {
		INTERNAL_CALL_Custom ( ref start, ref end, ref color, duration, depthTest );
	}

	[uei.ExcludeFromDocs]
	public static void Custom (Vector3 start, Vector3 end, Color color , float duration ) {
		bool depthTest = true;
		INTERNAL_CALL_Custom ( ref start, ref end, ref color, duration, depthTest );
	}

	[uei.ExcludeFromDocs]
	public static void Custom (Vector3 start, Vector3 end, Color color ) {
		bool depthTest = true;
		float duration = 0.0f;
		INTERNAL_CALL_Custom ( ref start, ref end, ref color, duration, depthTest );
	}

	[uei.ExcludeFromDocs]
	public static void Custom (Vector3 start, Vector3 end) {
		bool depthTest = true;
		float duration = 0.0f;
		Color color = Color.white;
		INTERNAL_CALL_Custom ( ref start, ref end, ref color, duration, depthTest );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_Custom (ref Vector3 start, ref Vector3 end, ref Color color, float duration, bool depthTest);
	[uei.ExcludeFromDocs]
public static void Raw (Vector3 start, Vector3 end, Color color , float duration ) {
	bool depthTest = true;
	Raw ( start, end, color, duration, depthTest );
}

[uei.ExcludeFromDocs]
public static void Raw (Vector3 start, Vector3 end, Color color ) {
	bool depthTest = true;
	float duration = 0.0f;
	Raw ( start, end, color, duration, depthTest );
}

[uei.ExcludeFromDocs]
public static void Raw (Vector3 start, Vector3 end) {
	bool depthTest = true;
	float duration = 0.0f;
	Color color = Color.white;
	Raw ( start, end, color, duration, depthTest );
}

public static void Raw(Vector3 start, Vector3 end, [uei.DefaultValue("Color.white")]  Color color , [uei.DefaultValue("0.0f")]  float duration , [uei.DefaultValue("true")]  bool depthTest ) { DebugDrawLine (start, end, color, duration, depthTest); }

}

