SCRIPT_BINDINGS_EXPORT_DECL
ScriptingStringPtr SCRIPT_CALL_CONVENTION Test_CUSTOM_ToString()
{
	SCRIPTINGAPI_STACK_CHECK(ToString)
	SCRIPTINGAPI_THREAD_CHECK(ToString)
	
			return CreateScriptingString(GetSafeString(BaseObject, UnityObjectToString (self)));
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Test_ToString()
{
	mono_add_internal_call( "UnityEngine.Test::ToString" , (gpointer)& Test_CUSTOM_ToString );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_RawBlockMultipleMethodsOneConditional2_IcallNames [] =
{
	"UnityEngine.Test::ToString"            ,	// -> Test_CUSTOM_ToString
	NULL
};

static const void* s_RawBlockMultipleMethodsOneConditional2_IcallFuncs [] =
{
	(const void*)&Test_CUSTOM_ToString                    ,	//  <- UnityEngine.Test::ToString
	NULL
};

void ExportRawBlockMultipleMethodsOneConditional2Bindings();
void ExportRawBlockMultipleMethodsOneConditional2Bindings()
{
	for (int i = 0; s_RawBlockMultipleMethodsOneConditional2_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_RawBlockMultipleMethodsOneConditional2_IcallNames [i], s_RawBlockMultipleMethodsOneConditional2_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportRawBlockMultipleMethodsOneConditional2Bindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Test_CUSTOM_ToString);	//  <- UnityEngine.Test::ToString
}

#endif
