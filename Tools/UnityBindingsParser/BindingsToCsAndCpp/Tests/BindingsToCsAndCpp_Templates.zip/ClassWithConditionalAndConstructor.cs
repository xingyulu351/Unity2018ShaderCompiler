using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class AnimationCurve
{
#if UNITY_FLASH || UNITY_METRO
	public AnimationCurve(IntPtr nativeptr) { m_Ptr = nativeptr; }
#endif
		
	public AnimationCurve ()  { Init(null); }
}

