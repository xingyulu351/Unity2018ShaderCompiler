
struct QualityCurvesTime
{
	float	fixedTime;
	float	variableEndStart;
	float	variableEndEnd;
	int		q;
};
#if (UNITY_EDITOR) && (UNITY_EDITOR)
SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MuscleClipEditorUtilities_CUSTOM_GetMuscleClipQualityInfo(ReadOnlyScriptingObjectOfType<AnimationClip> clip, float startTime, float stopTime)
{
	SCRIPTINGAPI_STACK_CHECK(GetMuscleClipQualityInfo)
	SCRIPTINGAPI_THREAD_CHECK(GetMuscleClipQualityInfo)
	
			MonoObject *obj = mono_object_new (mono_domain_get(), MONO_COMMON.muscleClipQualityInfo);
			MuscleClipQualityInfoToMono(clip->GetMuscleClipQualityInfo(startTime,stopTime),ExtractMonoObjectData<MonoMuscleClipQualityInfo>(obj));
			return obj;
		
}

#endif
#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
#if (UNITY_EDITOR) && (UNITY_EDITOR)
void Register_UnityEngine_MuscleClipEditorUtilities_GetMuscleClipQualityInfo()
{
	mono_add_internal_call( "UnityEngine.MuscleClipEditorUtilities::GetMuscleClipQualityInfo" , (gpointer)& MuscleClipEditorUtilities_CUSTOM_GetMuscleClipQualityInfo );
}

#endif
#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_MultipleConditionsOnCppAndCsraw_IcallNames [] =
{
#if (UNITY_EDITOR) && (UNITY_EDITOR)
	"UnityEngine.MuscleClipEditorUtilities::GetMuscleClipQualityInfo",	// -> MuscleClipEditorUtilities_CUSTOM_GetMuscleClipQualityInfo
#endif
	NULL
};

static const void* s_MultipleConditionsOnCppAndCsraw_IcallFuncs [] =
{
#if (UNITY_EDITOR) && (UNITY_EDITOR)
	(const void*)&MuscleClipEditorUtilities_CUSTOM_GetMuscleClipQualityInfo,	//  <- UnityEngine.MuscleClipEditorUtilities::GetMuscleClipQualityInfo
#endif
	NULL
};

void ExportMultipleConditionsOnCppAndCsrawBindings();
void ExportMultipleConditionsOnCppAndCsrawBindings()
{
	for (int i = 0; s_MultipleConditionsOnCppAndCsraw_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_MultipleConditionsOnCppAndCsraw_IcallNames [i], s_MultipleConditionsOnCppAndCsraw_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportMultipleConditionsOnCppAndCsrawBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
#if (UNITY_EDITOR) && (UNITY_EDITOR)
	SET_METRO_BINDING(MuscleClipEditorUtilities_CUSTOM_GetMuscleClipQualityInfo);	//  <- UnityEngine.MuscleClipEditorUtilities::GetMuscleClipQualityInfo
#endif
}

#endif
