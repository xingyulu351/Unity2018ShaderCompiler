using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	public string GetStringUTFChars (IntPtr str) {
		return INTERNAL_CALL_GetStringUTFChars ( this, str );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static string INTERNAL_CALL_GetStringUTFChars (Camera self, IntPtr str);
}

