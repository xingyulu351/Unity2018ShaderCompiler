using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
public sealed partial class AlignedBuffer
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private IntPtr AllocBuffer (int size, Memory mem, int alignmem) ;

}

