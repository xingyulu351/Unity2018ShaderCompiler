using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
public sealed partial class Camera : Behaviour
{
	
	static void LoadScriptInfos () {
if( (Char)o == '"' )				return "\"\\\"\""; 
	}
}

