using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
#if ACONDITION
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  void MyMethod () ;

#endif
#if ACONDITION
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  void MyMethod1 () ;

#endif
}

