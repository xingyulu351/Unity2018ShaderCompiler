using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Test
{
#if UNITY_XENON_API
	
	public enum X360AchievementType : uint	
	{
		Completion = 1,
		Leveling,
		Unlock,
		Event,
		Tournament,
		Checkpoint,
		Other
	}

#endif
	public extern float frameRate
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

