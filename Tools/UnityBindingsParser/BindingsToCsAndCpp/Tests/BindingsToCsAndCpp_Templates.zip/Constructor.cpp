SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION NavMeshPath_CUSTOM_NavMeshPath(ScriptingObjectPtr self)
{
	SCRIPTINGAPI_STACK_CHECK(.ctor)
	SCRIPTINGAPI_THREAD_CHECK(.ctor)
	
			MonoNavMeshPath managedPath;
			managedPath.native = new NavMeshPath ();
			MarshallNativeStructIntoManaged (managedPath,self);
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_NavMeshPath__ctor()
{
	mono_add_internal_call( "UnityEngine.NavMeshPath::.ctor" , (gpointer)& NavMeshPath_CUSTOM_NavMeshPath );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Constructor_IcallNames [] =
{
	"UnityEngine.NavMeshPath::.ctor"        ,	// -> NavMeshPath_CUSTOM_NavMeshPath
	NULL
};

static const void* s_Constructor_IcallFuncs [] =
{
	(const void*)&NavMeshPath_CUSTOM_NavMeshPath          ,	//  <- UnityEngine.NavMeshPath::.ctor
	NULL
};

void ExportConstructorBindings();
void ExportConstructorBindings()
{
	for (int i = 0; s_Constructor_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Constructor_IcallNames [i], s_Constructor_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportConstructorBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(NavMeshPath_CUSTOM_NavMeshPath);	//  <- UnityEngine.NavMeshPath::.ctor
}

#endif
