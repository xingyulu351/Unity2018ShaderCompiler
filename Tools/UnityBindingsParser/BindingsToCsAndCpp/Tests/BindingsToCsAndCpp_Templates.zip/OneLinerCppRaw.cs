using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
[System.Runtime.InteropServices.StructLayout (System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct Keyframe
{
	float m_Time;
	float m_Value;
	float m_InTangent;
	float m_OutTangent;
}

#pragma warning disable 414


[StructLayout (LayoutKind.Sequential)]
public sealed partial class AnimationCurve
{
	
		internal IntPtr m_Ptr;
		
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private void Cleanup () ;

}

}
