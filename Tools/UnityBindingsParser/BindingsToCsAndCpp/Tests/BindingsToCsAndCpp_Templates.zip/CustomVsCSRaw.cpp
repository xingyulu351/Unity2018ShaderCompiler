SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_CALL_Custom(const Vector3f& start, const Vector3f& end, const ColorRGBAf& color, float duration, ScriptingBool depthTest)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_Custom)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_CALL_Custom)
	 DebugDrawLine (start, end, color, duration, depthTest); 
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_MyClass_INTERNAL_CALL_Custom()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_CALL_Custom" , (gpointer)& MyClass_CUSTOM_INTERNAL_CALL_Custom );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomVsCSRaw_IcallNames [] =
{
	"UnityEngine.MyClass::INTERNAL_CALL_Custom",	// -> MyClass_CUSTOM_INTERNAL_CALL_Custom
	NULL
};

static const void* s_CustomVsCSRaw_IcallFuncs [] =
{
	(const void*)&MyClass_CUSTOM_INTERNAL_CALL_Custom     ,	//  <- UnityEngine.MyClass::INTERNAL_CALL_Custom
	NULL
};

void ExportCustomVsCSRawBindings();
void ExportCustomVsCSRawBindings()
{
	for (int i = 0; s_CustomVsCSRaw_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomVsCSRaw_IcallNames [i], s_CustomVsCSRaw_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomVsCSRawBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_CALL_Custom);	//  <- UnityEngine.MyClass::INTERNAL_CALL_Custom
}

#endif
