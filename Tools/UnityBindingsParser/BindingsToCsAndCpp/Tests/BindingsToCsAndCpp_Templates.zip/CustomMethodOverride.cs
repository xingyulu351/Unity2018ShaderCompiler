using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
public sealed partial class Camera
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public override static  int myProp () ;

}

