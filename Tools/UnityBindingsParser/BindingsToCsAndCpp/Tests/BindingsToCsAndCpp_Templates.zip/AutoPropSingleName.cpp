SCRIPT_BINDINGS_EXPORT_DECL
ICallString SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropFrameRate(ReadOnlyScriptingObjectOfType<Camera> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_frameRate)
	SCRIPTINGAPI_THREAD_CHECK(get_frameRate)
	return self->SampleRate ();
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_get_frameRate()
{
	mono_add_internal_call( "UnityEngine.Camera::get_frameRate" , (gpointer)& Camera_Get_Custom_PropFrameRate );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_AutoPropSingleName_IcallNames [] =
{
	"UnityEngine.Camera::get_frameRate"     ,	// -> Camera_Get_Custom_PropFrameRate
	NULL
};

static const void* s_AutoPropSingleName_IcallFuncs [] =
{
	(const void*)&Camera_Get_Custom_PropFrameRate         ,	//  <- UnityEngine.Camera::get_frameRate
	NULL
};

void ExportAutoPropSingleNameBindings();
void ExportAutoPropSingleNameBindings()
{
	for (int i = 0; s_AutoPropSingleName_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_AutoPropSingleName_IcallNames [i], s_AutoPropSingleName_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportAutoPropSingleNameBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_Get_Custom_PropFrameRate);	//  <- UnityEngine.Camera::get_frameRate
}

#endif
