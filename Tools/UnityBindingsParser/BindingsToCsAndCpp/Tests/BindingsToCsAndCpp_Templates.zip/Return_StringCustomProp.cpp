SCRIPT_BINDINGS_EXPORT_DECL
ScriptingStringPtr SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropGetStringUTFChars(ReadOnlyScriptingObjectOfType<Camera> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_GetStringUTFChars)
	SCRIPTINGAPI_THREAD_CHECK(get_GetStringUTFChars)
	return SCRIPTING_NULL;
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingStringPtr SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropGetStringUTFCharsStatic()
{
	SCRIPTINGAPI_STACK_CHECK(get_GetStringUTFCharsStatic)
	SCRIPTINGAPI_THREAD_CHECK(get_GetStringUTFCharsStatic)
	return SCRIPTING_NULL;
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_get_GetStringUTFChars()
{
	mono_add_internal_call( "UnityEngine.Camera::get_GetStringUTFChars" , (gpointer)& Camera_Get_Custom_PropGetStringUTFChars );
}

void Register_UnityEngine_Camera_get_GetStringUTFCharsStatic()
{
	mono_add_internal_call( "UnityEngine.Camera::get_GetStringUTFCharsStatic" , (gpointer)& Camera_Get_Custom_PropGetStringUTFCharsStatic );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Return_StringCustomProp_IcallNames [] =
{
	"UnityEngine.Camera::get_GetStringUTFChars",	// -> Camera_Get_Custom_PropGetStringUTFChars
	"UnityEngine.Camera::get_GetStringUTFCharsStatic",	// -> Camera_Get_Custom_PropGetStringUTFCharsStatic
	NULL
};

static const void* s_Return_StringCustomProp_IcallFuncs [] =
{
	(const void*)&Camera_Get_Custom_PropGetStringUTFChars ,	//  <- UnityEngine.Camera::get_GetStringUTFChars
	(const void*)&Camera_Get_Custom_PropGetStringUTFCharsStatic,	//  <- UnityEngine.Camera::get_GetStringUTFCharsStatic
	NULL
};

void ExportReturn_StringCustomPropBindings();
void ExportReturn_StringCustomPropBindings()
{
	for (int i = 0; s_Return_StringCustomProp_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Return_StringCustomProp_IcallNames [i], s_Return_StringCustomProp_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportReturn_StringCustomPropBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_Get_Custom_PropGetStringUTFChars);	//  <- UnityEngine.Camera::get_GetStringUTFChars
	SET_METRO_BINDING(Camera_Get_Custom_PropGetStringUTFCharsStatic);	//  <- UnityEngine.Camera::get_GetStringUTFCharsStatic
}

#endif
