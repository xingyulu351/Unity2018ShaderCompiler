using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
#if ENABLE_AUDIO
	[uei.ExcludeFromDocs]
public static void PlayClipAtPoint (AudioClip clip, Vector3 position) {
	float volume = 1.0F;
	PlayClipAtPoint ( clip, position, volume );
}

public static void PlayClipAtPoint(AudioClip clip, Vector3 position, [uei.DefaultValue("1.0F")]  float volume )
	{
		GameObject go = new GameObject ("One shot audio");
		go.transform.position = position;
		AudioSource source = (AudioSource)go.AddComponent (typeof(AudioSource));
		source.clip = clip;
		source.volume = volume;
		source.Play ();
		Destroy (go, clip.length * Time.timeScale);
	}

#endif
}

