using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
internal sealed partial class ScrollViewState
{
			public Rect scrollTo;
	
	
			 
	
	internal void ScrollTo (Rect position) {
			Vector2 pos = new Vector2 (position.xMin, position.yMin);
			if (!hasScrollTo) {
			}
		}
}

