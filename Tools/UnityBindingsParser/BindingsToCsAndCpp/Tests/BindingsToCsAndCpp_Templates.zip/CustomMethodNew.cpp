SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_CUSTOM_myProp()
{
	SCRIPTINGAPI_STACK_CHECK(myProp)
	SCRIPTINGAPI_THREAD_CHECK(myProp)
	
			return 0;
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_myProp()
{
	mono_add_internal_call( "UnityEngine.Camera::myProp" , (gpointer)& Camera_CUSTOM_myProp );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomMethodNew_IcallNames [] =
{
	"UnityEngine.Camera::myProp"            ,	// -> Camera_CUSTOM_myProp
	NULL
};

static const void* s_CustomMethodNew_IcallFuncs [] =
{
	(const void*)&Camera_CUSTOM_myProp                    ,	//  <- UnityEngine.Camera::myProp
	NULL
};

void ExportCustomMethodNewBindings();
void ExportCustomMethodNewBindings()
{
	for (int i = 0; s_CustomMethodNew_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomMethodNew_IcallNames [i], s_CustomMethodNew_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomMethodNewBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_CUSTOM_myProp);	//  <- UnityEngine.Camera::myProp
}

#endif
