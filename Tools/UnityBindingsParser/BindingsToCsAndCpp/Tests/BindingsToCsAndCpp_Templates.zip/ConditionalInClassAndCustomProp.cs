using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
#if ACONDITION
public sealed partial class Camera
{
#if ANOTHERCONDITION
	public extern static int myProp
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

#endif
	public extern static int myProp2
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

#endif
