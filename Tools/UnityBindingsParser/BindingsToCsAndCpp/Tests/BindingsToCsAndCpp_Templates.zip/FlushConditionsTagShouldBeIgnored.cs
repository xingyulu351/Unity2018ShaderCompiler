using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;


public sealed partial class Camera : Behaviour
{
#if MAYBE
	public float fov { get { return fieldOfView; } set { fieldOfView = value; } }
#endif
	public float fov2 { get { return fieldOfView; } set { fieldOfView = value; } }
}

