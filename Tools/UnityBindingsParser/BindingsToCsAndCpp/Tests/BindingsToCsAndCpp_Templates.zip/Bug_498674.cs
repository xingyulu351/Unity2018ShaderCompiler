using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	public void PublicMethodVector3WritableTexture2D (Vector3 v, [Writable]Texture2D tex) {
		INTERNAL_CALL_PublicMethodVector3WritableTexture2D ( this, ref v, tex );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_PublicMethodVector3WritableTexture2D (MyClass self, ref Vector3 v, [Writable]Texture2D tex);
	public static void PublicStaticMethodVector3WritableTexture2D (Vector3 v, [Writable]Texture2D tex) {
		INTERNAL_CALL_PublicStaticMethodVector3WritableTexture2D ( ref v, tex );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_PublicStaticMethodVector3WritableTexture2D (ref Vector3 v, [Writable]Texture2D tex);
}

