using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	public Vector3 GetVector3 () {
		return INTERNAL_CALL_GetVector3 ( this );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static Vector3 INTERNAL_CALL_GetVector3 (Camera self);
}

