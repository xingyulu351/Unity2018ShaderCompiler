using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
#if ENABLE_AUDIO
	[System.Obsolete ("A Warning")]
	public AnimationClip GetClip (string name) {
		return null;
	}
#endif
}

