using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
#if ENABLE_2D_PHYSICS
[StructLayout (LayoutKind.Sequential)]
public partial class Collision2D
{
	internal Rigidbody2D    m_Rigidbody;
	internal Collider2D     m_Collider;
		
	public Rigidbody2D rigidbody { get { return m_Rigidbody; } }
	public Collider2D collider { get { return m_Collider; } }
	public Transform transform { get { return rigidbody != null ? rigidbody.transform : collider.transform; } }
	public GameObject gameObject { get { return m_Rigidbody != null ? m_Rigidbody.gameObject : m_Collider.gameObject; } }
}

#endif
}
