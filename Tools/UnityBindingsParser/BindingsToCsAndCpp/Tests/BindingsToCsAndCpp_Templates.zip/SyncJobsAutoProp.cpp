SCRIPT_BINDINGS_EXPORT_DECL
float SCRIPT_CALL_CONVENTION TestClass_Get_Custom_PropStartDelay(ReadOnlyScriptingObjectOfType<TestClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_startDelay)
	SCRIPTINGAPI_THREAD_CHECK(get_startDelay) self->SyncJobs();
	return self->GetStartDelay ();
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION TestClass_Set_Custom_PropStartDelay(ReadOnlyScriptingObjectOfType<TestClass> self, float value)
{
	SCRIPTINGAPI_STACK_CHECK(set_startDelay)
	SCRIPTINGAPI_THREAD_CHECK(set_startDelay) self->SyncJobs();
	
	self->SetStartDelay (value);
	
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_TestClass_get_startDelay()
{
	mono_add_internal_call( "UnityEngine.TestClass::get_startDelay" , (gpointer)& TestClass_Get_Custom_PropStartDelay );
}

void Register_UnityEngine_TestClass_set_startDelay()
{
	mono_add_internal_call( "UnityEngine.TestClass::set_startDelay" , (gpointer)& TestClass_Set_Custom_PropStartDelay );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_SyncJobsAutoProp_IcallNames [] =
{
	"UnityEngine.TestClass::get_startDelay" ,	// -> TestClass_Get_Custom_PropStartDelay
	"UnityEngine.TestClass::set_startDelay" ,	// -> TestClass_Set_Custom_PropStartDelay
	NULL
};

static const void* s_SyncJobsAutoProp_IcallFuncs [] =
{
	(const void*)&TestClass_Get_Custom_PropStartDelay     ,	//  <- UnityEngine.TestClass::get_startDelay
	(const void*)&TestClass_Set_Custom_PropStartDelay     ,	//  <- UnityEngine.TestClass::set_startDelay
	NULL
};

void ExportSyncJobsAutoPropBindings();
void ExportSyncJobsAutoPropBindings()
{
	for (int i = 0; s_SyncJobsAutoProp_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_SyncJobsAutoProp_IcallNames [i], s_SyncJobsAutoProp_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportSyncJobsAutoPropBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(TestClass_Get_Custom_PropStartDelay);	//  <- UnityEngine.TestClass::get_startDelay
	SET_METRO_BINDING(TestClass_Set_Custom_PropStartDelay);	//  <- UnityEngine.TestClass::set_startDelay
}

#endif
