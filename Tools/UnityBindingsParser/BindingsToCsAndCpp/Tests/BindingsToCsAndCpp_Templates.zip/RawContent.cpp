SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION ScrollViewState_Get_Custom_PropMouseUsed()
{
	SCRIPTINGAPI_STACK_CHECK(get_mouseUsed)
	SCRIPTINGAPI_THREAD_CHECK(get_mouseUsed)
	return GetGUIState().m_CanvasGUIState.m_IsMouseUsed != 0;
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION ScrollViewState_Set_Custom_PropMouseUsed(ScriptingBool value)
{
	SCRIPTINGAPI_STACK_CHECK(set_mouseUsed)
	SCRIPTINGAPI_THREAD_CHECK(set_mouseUsed)
	 GetGUIState().m_CanvasGUIState.m_IsMouseUsed = value ? 1 : 0; 
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine;_ScrollViewState_get_mouseUsed()
{
	mono_add_internal_call( "UnityEngine;.ScrollViewState::get_mouseUsed" , (gpointer)& ScrollViewState_Get_Custom_PropMouseUsed );
}

void Register_UnityEngine;_ScrollViewState_set_mouseUsed()
{
	mono_add_internal_call( "UnityEngine;.ScrollViewState::set_mouseUsed" , (gpointer)& ScrollViewState_Set_Custom_PropMouseUsed );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_RawContent_IcallNames [] =
{
	"UnityEngine;.ScrollViewState::get_mouseUsed",	// -> ScrollViewState_Get_Custom_PropMouseUsed
	"UnityEngine;.ScrollViewState::set_mouseUsed",	// -> ScrollViewState_Set_Custom_PropMouseUsed
	NULL
};

static const void* s_RawContent_IcallFuncs [] =
{
	(const void*)&ScrollViewState_Get_Custom_PropMouseUsed,	//  <- UnityEngine;.ScrollViewState::get_mouseUsed
	(const void*)&ScrollViewState_Set_Custom_PropMouseUsed,	//  <- UnityEngine;.ScrollViewState::set_mouseUsed
	NULL
};

void ExportRawContentBindings();
void ExportRawContentBindings()
{
	for (int i = 0; s_RawContent_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_RawContent_IcallNames [i], s_RawContent_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportRawContentBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(ScrollViewState_Get_Custom_PropMouseUsed);	//  <- UnityEngine;.ScrollViewState::get_mouseUsed
	SET_METRO_BINDING(ScrollViewState_Set_Custom_PropMouseUsed);	//  <- UnityEngine;.ScrollViewState::set_mouseUsed
}

#endif
