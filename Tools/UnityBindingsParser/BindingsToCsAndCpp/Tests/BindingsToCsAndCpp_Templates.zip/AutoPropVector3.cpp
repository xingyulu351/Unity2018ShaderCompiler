SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION Camera_CUSTOM_INTERNAL_get_vector3Auto(ReadOnlyScriptingObjectOfType<Camera> self, Vector3f& value)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_get_vector3Auto)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_get_vector3Auto)
	value = self->Vector3Auto();
	
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_INTERNAL_get_vector3Auto()
{
	mono_add_internal_call( "UnityEngine.Camera::INTERNAL_get_vector3Auto" , (gpointer)& Camera_CUSTOM_INTERNAL_get_vector3Auto );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_AutoPropVector3_IcallNames [] =
{
	"UnityEngine.Camera::INTERNAL_get_vector3Auto",	// -> Camera_CUSTOM_INTERNAL_get_vector3Auto
	NULL
};

static const void* s_AutoPropVector3_IcallFuncs [] =
{
	(const void*)&Camera_CUSTOM_INTERNAL_get_vector3Auto  ,	//  <- UnityEngine.Camera::INTERNAL_get_vector3Auto
	NULL
};

void ExportAutoPropVector3Bindings();
void ExportAutoPropVector3Bindings()
{
	for (int i = 0; s_AutoPropVector3_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_AutoPropVector3_IcallNames [i], s_AutoPropVector3_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportAutoPropVector3Bindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_CUSTOM_INTERNAL_get_vector3Auto);	//  <- UnityEngine.Camera::INTERNAL_get_vector3Auto
}

#endif
