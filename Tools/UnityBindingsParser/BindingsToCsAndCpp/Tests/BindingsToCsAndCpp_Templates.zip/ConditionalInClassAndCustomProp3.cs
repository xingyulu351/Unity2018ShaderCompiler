using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
#if ACONDITION
public sealed partial class Camera
{
	public extern static int myProp
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern static int myProp2
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

#if ANOTHERCONDITION
	public extern static int myProp3
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

#endif
}

#endif
