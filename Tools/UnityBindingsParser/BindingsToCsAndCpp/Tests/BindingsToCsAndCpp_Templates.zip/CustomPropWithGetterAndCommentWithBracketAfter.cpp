SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION Unsupported_Get_Custom_PropImeIsSelected()
{
	SCRIPTINGAPI_STACK_CHECK(get_imeIsSelected)
	SCRIPTINGAPI_THREAD_CHECK(get_imeIsSelected)
	return (GetInputManager().GetIMEIsSelected());
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Unsupported_get_imeIsSelected()
{
	mono_add_internal_call( "UnityEngine.Unsupported::get_imeIsSelected" , (gpointer)& Unsupported_Get_Custom_PropImeIsSelected );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomPropWithGetterAndCommentWithBracketAfter_IcallNames [] =
{
	"UnityEngine.Unsupported::get_imeIsSelected",	// -> Unsupported_Get_Custom_PropImeIsSelected
	NULL
};

static const void* s_CustomPropWithGetterAndCommentWithBracketAfter_IcallFuncs [] =
{
	(const void*)&Unsupported_Get_Custom_PropImeIsSelected,	//  <- UnityEngine.Unsupported::get_imeIsSelected
	NULL
};

void ExportCustomPropWithGetterAndCommentWithBracketAfterBindings();
void ExportCustomPropWithGetterAndCommentWithBracketAfterBindings()
{
	for (int i = 0; s_CustomPropWithGetterAndCommentWithBracketAfter_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomPropWithGetterAndCommentWithBracketAfter_IcallNames [i], s_CustomPropWithGetterAndCommentWithBracketAfter_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomPropWithGetterAndCommentWithBracketAfterBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Unsupported_Get_Custom_PropImeIsSelected);	//  <- UnityEngine.Unsupported::get_imeIsSelected
}

#endif
