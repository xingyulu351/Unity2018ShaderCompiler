SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION TerrainRenderer_CUSTOM_SetData(ReadOnlyScriptingObjectOfType<TerrainRenderer> self, ScriptingArrayPtr data, int offsetSamples)
{
	SCRIPTINGAPI_STACK_CHECK(SetData)
	SCRIPTINGAPI_THREAD_CHECK(SetData)
	
			self->SetData(&GetScriptingArrayElement<float>(data, 0), GetScriptingArraySize (data) / self->GetChannelCount(), offsetSamples);
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_TerrainRenderer_SetData()
{
	mono_add_internal_call( "UnityEngine.TerrainRenderer::SetData" , (gpointer)& TerrainRenderer_CUSTOM_SetData );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomBlockFollowedByConditionalCsRaw_IcallNames [] =
{
	"UnityEngine.TerrainRenderer::SetData"  ,	// -> TerrainRenderer_CUSTOM_SetData
	NULL
};

static const void* s_CustomBlockFollowedByConditionalCsRaw_IcallFuncs [] =
{
	(const void*)&TerrainRenderer_CUSTOM_SetData          ,	//  <- UnityEngine.TerrainRenderer::SetData
	NULL
};

void ExportCustomBlockFollowedByConditionalCsRawBindings();
void ExportCustomBlockFollowedByConditionalCsRawBindings()
{
	for (int i = 0; s_CustomBlockFollowedByConditionalCsRaw_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomBlockFollowedByConditionalCsRaw_IcallNames [i], s_CustomBlockFollowedByConditionalCsRaw_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomBlockFollowedByConditionalCsRawBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(TerrainRenderer_CUSTOM_SetData);	//  <- UnityEngine.TerrainRenderer::SetData
}

#endif
