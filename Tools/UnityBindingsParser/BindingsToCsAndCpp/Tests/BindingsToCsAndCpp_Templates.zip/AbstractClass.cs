using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEditor
{
public abstract partial class PropertyAttribute : Attribute
{
}

