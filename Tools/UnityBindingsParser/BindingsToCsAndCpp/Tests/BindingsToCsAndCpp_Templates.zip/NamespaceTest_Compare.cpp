SCRIPT_BINDINGS_EXPORT_DECL
ScriptingArrayPtr SCRIPT_CALL_CONVENTION File_CUSTOM_ReadAllBytes(ICallString path)
{
	SCRIPTINGAPI_STACK_CHECK(ReadAllBytes)
	SCRIPTINGAPI_THREAD_CHECK(ReadAllBytes)
	
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_WSA_File_ReadAllBytes()
{
	mono_add_internal_call( "UnityEngine.WSA.File::ReadAllBytes" , (gpointer)& File_CUSTOM_ReadAllBytes );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_NamespaceTest_Compare_IcallNames [] =
{
	"UnityEngine.WSA.File::ReadAllBytes"    ,	// -> File_CUSTOM_ReadAllBytes
	NULL
};

static const void* s_NamespaceTest_Compare_IcallFuncs [] =
{
	(const void*)&File_CUSTOM_ReadAllBytes                ,	//  <- UnityEngine.WSA.File::ReadAllBytes
	NULL
};

void ExportNamespaceTest_CompareBindings();
void ExportNamespaceTest_CompareBindings()
{
	for (int i = 0; s_NamespaceTest_Compare_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_NamespaceTest_Compare_IcallNames [i], s_NamespaceTest_Compare_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportNamespaceTest_CompareBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(File_CUSTOM_ReadAllBytes);	//  <- UnityEngine.WSA.File::ReadAllBytes
}

#endif
