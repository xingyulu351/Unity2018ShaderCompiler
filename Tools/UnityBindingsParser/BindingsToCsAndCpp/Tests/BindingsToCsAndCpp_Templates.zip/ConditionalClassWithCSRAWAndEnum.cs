using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEditor.VersionControl
{
#if ENABLE_VERSION_CONTROL_INTEGRATION
public sealed partial class VCAsset
{
	[Flags]
	public enum States	
	{
		None = 0,
	}

}

#endif

}
