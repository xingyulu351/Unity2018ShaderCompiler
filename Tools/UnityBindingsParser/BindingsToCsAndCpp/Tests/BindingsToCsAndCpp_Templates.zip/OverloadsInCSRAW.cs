using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	[uei.ExcludeFromDocs]
public bool Play () {
	PlayMode mode = PlayMode.StopSameLayer;
	return Play ( mode );
}

public bool Play( [uei.DefaultValue("PlayMode.StopSameLayer")] PlayMode mode ) { return PlayDefaultAnimation (mode); }

	
	
	public bool Play (PlayMode mode ) { return PlayDefaultAnimation (mode); }
}

