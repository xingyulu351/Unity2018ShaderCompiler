SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_CUSTOM_GetStringUTFChars(ReadOnlyScriptingObjectOfType<Camera> self, void* str)
{
	SCRIPTINGAPI_STACK_CHECK(GetStringUTFChars)
	SCRIPTINGAPI_THREAD_CHECK(GetStringUTFChars)
	
			return 0;
		
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_CUSTOM_GetStringUTFCharsStatic(void* str)
{
	SCRIPTINGAPI_STACK_CHECK(GetStringUTFCharsStatic)
	SCRIPTINGAPI_THREAD_CHECK(GetStringUTFCharsStatic)
	
			return 0;
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_GetStringUTFChars()
{
	mono_add_internal_call( "UnityEngine.Camera::GetStringUTFChars" , (gpointer)& Camera_CUSTOM_GetStringUTFChars );
}

void Register_UnityEngine_Camera_GetStringUTFCharsStatic()
{
	mono_add_internal_call( "UnityEngine.Camera::GetStringUTFCharsStatic" , (gpointer)& Camera_CUSTOM_GetStringUTFCharsStatic );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Return_IntCustom_IcallNames [] =
{
	"UnityEngine.Camera::GetStringUTFChars" ,	// -> Camera_CUSTOM_GetStringUTFChars
	"UnityEngine.Camera::GetStringUTFCharsStatic",	// -> Camera_CUSTOM_GetStringUTFCharsStatic
	NULL
};

static const void* s_Return_IntCustom_IcallFuncs [] =
{
	(const void*)&Camera_CUSTOM_GetStringUTFChars         ,	//  <- UnityEngine.Camera::GetStringUTFChars
	(const void*)&Camera_CUSTOM_GetStringUTFCharsStatic   ,	//  <- UnityEngine.Camera::GetStringUTFCharsStatic
	NULL
};

void ExportReturn_IntCustomBindings();
void ExportReturn_IntCustomBindings()
{
	for (int i = 0; s_Return_IntCustom_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Return_IntCustom_IcallNames [i], s_Return_IntCustom_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportReturn_IntCustomBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_CUSTOM_GetStringUTFChars);	//  <- UnityEngine.Camera::GetStringUTFChars
	SET_METRO_BINDING(Camera_CUSTOM_GetStringUTFCharsStatic);	//  <- UnityEngine.Camera::GetStringUTFCharsStatic
}

#endif
