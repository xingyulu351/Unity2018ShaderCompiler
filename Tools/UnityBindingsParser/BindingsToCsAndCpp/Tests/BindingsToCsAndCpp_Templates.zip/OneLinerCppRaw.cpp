static void CleanupAnimationCurve(void* animationCurve){ delete ((AnimationCurve*)animationCurve); };
SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION AnimationCurve_CUSTOM_Cleanup(ScriptingObjectWithIntPtrField<AnimationCurve> self)
{
	SCRIPTINGAPI_STACK_CHECK(Cleanup)
	 CleanupAnimationCurve(self.GetPtr()); 
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_AnimationCurve_Cleanup()
{
	mono_add_internal_call( "UnityEngine.AnimationCurve::Cleanup" , (gpointer)& AnimationCurve_CUSTOM_Cleanup );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_OneLinerCppRaw_IcallNames [] =
{
	"UnityEngine.AnimationCurve::Cleanup"   ,	// -> AnimationCurve_CUSTOM_Cleanup
	NULL
};

static const void* s_OneLinerCppRaw_IcallFuncs [] =
{
	(const void*)&AnimationCurve_CUSTOM_Cleanup           ,	//  <- UnityEngine.AnimationCurve::Cleanup
	NULL
};

void ExportOneLinerCppRawBindings();
void ExportOneLinerCppRawBindings()
{
	for (int i = 0; s_OneLinerCppRaw_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_OneLinerCppRaw_IcallNames [i], s_OneLinerCppRaw_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportOneLinerCppRawBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(AnimationCurve_CUSTOM_Cleanup);	//  <- UnityEngine.AnimationCurve::Cleanup
}

#endif
