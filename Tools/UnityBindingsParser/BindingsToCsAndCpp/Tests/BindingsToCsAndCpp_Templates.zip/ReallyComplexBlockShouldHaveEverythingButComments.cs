using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class TerrainRenderer
{
	
	internal static void DoTextField (Rect position, int id, GUIContent content, bool multiline, int maxLength, GUIStyle style
#if UNITY_IPHONE || UNITY_ANDROID
		, string secureText = null
#endif
	) {

		if (maxLength >= 0 && content.text.Length > maxLength)
			content.text = content.text.Substring (0, maxLength);

		GUIUtility.CheckOnGUI ();
		TextEditor editor = (TextEditor)GUIUtility.GetStateObject (typeof (TextEditor), id);
		editor.content.text = content.text;
		editor.SaveBackup ();
		editor.position = position;
		editor.style = style;
		editor.multiline = multiline;
		editor.controlID = id;
		editor.ClampPos ();
		Event evt = Event.current;
		
#if UNITY_IPHONE || UNITY_ANDROID
		switch (evt.type) {
		case EventType.MouseDown:
			if (position.Contains (evt.mousePosition)) {
				GUIUtility.hotControl = id;

				if (hotTextField != -1 && hotTextField != id) {
					TextEditor currentEditor = (TextEditor)GUIUtility.GetStateObject (typeof (TextEditor), hotTextField);
					currentEditor.keyboardOnScreen = null;
				}

				hotTextField = id;

				if (GUIUtility.keyboardControl != id)
					GUIUtility.keyboardControl = id;

				editor.keyboardOnScreen = TouchScreenKeyboard.Open(
					(secureText != null) ? secureText : content.text,
					TouchScreenKeyboardType.Default,
					true, 
					multiline,
					(secureText != null));

				evt.Use ();
			}
			break;
			case EventType.Repaint:
				if (editor.keyboardOnScreen != null) {
					content.text = editor.keyboardOnScreen.text;
					if (maxLength >= 0 && content.text.Length > maxLength)
						content.text = content.text.Substring (0, maxLength);

					if (editor.keyboardOnScreen.done) {
						editor.keyboardOnScreen = null;
						changed = true;
					}
				}
				style.Draw (position, content, id, false);
				break;
		}
#else 
		bool change = false;
		switch (evt.type) {
		case EventType.MouseDown:
			if (position.Contains (evt.mousePosition)) {
				GUIUtility.hotControl = id;
				GUIUtility.keyboardControl = id;
				editor.m_HasFocus = true;
				editor.MoveCursorToPosition (Event.current.mousePosition);
				if (Event.current.clickCount == 2 && GUI.skin.settings.doubleClickSelectsWord) {
					editor.SelectCurrentWord ();
					editor.DblClickSnap(TextEditor.DblClickSnapping.WORDS);
					editor.MouseDragSelectsWholeWords (true);
				} if (Event.current.clickCount == 3 && GUI.skin.settings.tripleClickSelectsLine) {
					editor.SelectCurrentParagraph ();
					editor.MouseDragSelectsWholeWords (true);
					editor.DblClickSnap(TextEditor.DblClickSnapping.PARAGRAPHS);
				}
				evt.Use ();
			}
			break;
		case EventType.MouseDrag:
			if (GUIUtility.hotControl == id)
			{
				if (evt.shift)
					editor.MoveCursorToPosition (Event.current.mousePosition);
				else
					editor.SelectToPosition (Event.current.mousePosition);
				evt.Use ();
			}
			break;
		case EventType.MouseUp:
			if (GUIUtility.hotControl == id) {
				editor.MouseDragSelectsWholeWords (false);
				GUIUtility.hotControl = 0;
				evt.Use ();
			}
			break;
		case EventType.KeyDown:
			if (GUIUtility.keyboardControl != id)
				return;
							
			if (editor.HandleKeyEvent (evt)) {
				evt.Use ();
				change = true;
				content.text = editor.content.text;
				break;
			}

			if (evt.keyCode == KeyCode.Tab || evt.character == '\t')
				return;

			char c = evt.character;
			
			if (c == '\n' && !multiline && !evt.alt)
				return;

			
			Font font = style.font;
			if (!font)
				font = GUI.skin.font;
			
			if (font.HasCharacter (c) || c == '\n') {
				editor.Insert (c);
				change = true;
				break;
			}
			
			if (c == 0) {
			
				if (Input.compositionString.Length > 0)
				{
					editor.ReplaceSelection ("");
					change = true;
				}
				
				evt.Use ();
			}
			break;
		case EventType.Repaint:
			if (GUIUtility.keyboardControl != id) {
				style.Draw (position, content, id, false);
			} else {
				editor.DrawCursor (content.text);
			}
			break;
		}

		if (GUIUtility.keyboardControl == id)
			GUIUtility.textFieldInput = true;
				
		if (change) {
			changed = true;
			content.text = editor.content.text;
			if (maxLength >= 0 && content.text.Length > maxLength)
				content.text = content.text.Substring (0, maxLength);
			evt.Use ();
		}
	#endif  
	}
}

