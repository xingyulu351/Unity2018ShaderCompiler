using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Unsupported
{
	
	#if !UNITY_WEBGL
	[uei.ExcludeFromDocs]
public static string EscapeURL (string s) {
	Encoding e=System.Text.Encoding.UTF8;
	return EscapeURL ( s, e );
}

public static string EscapeURL(string s, [uei.DefaultValue("System.Text.Encoding.UTF8")]  Encoding e)
	{
		if (s == null)
			return null;

		if (s == "")
			return "";

		if (e == null)
			return null;

		return WWWTranscoder.URLEncode(s,e);
	}

	#endif
	
	
	
}

}
