#if ACONDITION
SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_MyMethod()
{
	SCRIPTINGAPI_STACK_CHECK(MyMethod)
	SCRIPTINGAPI_THREAD_CHECK(MyMethod)
	
			a++;
		
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_MyMethod1()
{
	SCRIPTINGAPI_STACK_CHECK(MyMethod1)
	SCRIPTINGAPI_THREAD_CHECK(MyMethod1)
	
			a++;
		
}

#endif
#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
#if ACONDITION
void Register_UnityEngine_MyClass_MyMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::MyMethod" , (gpointer)& MyClass_CUSTOM_MyMethod );
}

void Register_UnityEngine_MyClass_MyMethod1()
{
	mono_add_internal_call( "UnityEngine.MyClass::MyMethod1" , (gpointer)& MyClass_CUSTOM_MyMethod1 );
}

#endif
#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_ConditionalSameInDifferentMethods_IcallNames [] =
{
#if ACONDITION
	"UnityEngine.MyClass::MyMethod"         ,	// -> MyClass_CUSTOM_MyMethod
	"UnityEngine.MyClass::MyMethod1"        ,	// -> MyClass_CUSTOM_MyMethod1
#endif
	NULL
};

static const void* s_ConditionalSameInDifferentMethods_IcallFuncs [] =
{
#if ACONDITION
	(const void*)&MyClass_CUSTOM_MyMethod                 ,	//  <- UnityEngine.MyClass::MyMethod
	(const void*)&MyClass_CUSTOM_MyMethod1                ,	//  <- UnityEngine.MyClass::MyMethod1
#endif
	NULL
};

void ExportConditionalSameInDifferentMethodsBindings();
void ExportConditionalSameInDifferentMethodsBindings()
{
	for (int i = 0; s_ConditionalSameInDifferentMethods_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_ConditionalSameInDifferentMethods_IcallNames [i], s_ConditionalSameInDifferentMethods_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportConditionalSameInDifferentMethodsBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
#if ACONDITION
	SET_METRO_BINDING(MyClass_CUSTOM_MyMethod);	//  <- UnityEngine.MyClass::MyMethod
	SET_METRO_BINDING(MyClass_CUSTOM_MyMethod1);	//  <- UnityEngine.MyClass::MyMethod1
#endif
}

#endif
