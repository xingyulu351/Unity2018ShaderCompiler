using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
#if ENABLE_PHYSICS
[System.Runtime.InteropServices.StructLayout (System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct SoftJointLimit
{
	float m_Limit;
	float m_Bounciness;
	float m_Spring;
	float m_Damper;
		
	public float bounciness { get { return m_Bounciness; } set { m_Bounciness = value; } }
		
	[System.Obsolete ("Use SoftJointLimit.bounciness instead", true)]
	public float bouncyness { get { return m_Bounciness; } set { m_Bounciness = value; } }
}

#endif
[Flags]
public enum JointDriveMode
{
	None = 0
}

