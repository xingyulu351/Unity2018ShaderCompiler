#if UNITY_XENON_API
SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION Test_Get_Custom_PropTest(ReadOnlyScriptingObjectOfType<Test> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_test)
	SCRIPTINGAPI_THREAD_CHECK(get_test)
	return self->Test ();
}

#endif
SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION Test_Get_Custom_PropAnotherTest(ReadOnlyScriptingObjectOfType<Test> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_anotherTest)
	SCRIPTINGAPI_THREAD_CHECK(get_anotherTest)
	return self->AnotherTest ();
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
#if UNITY_XENON_API
void Register_UnityEngine_Test_get_test()
{
	mono_add_internal_call( "UnityEngine.Test::get_test" , (gpointer)& Test_Get_Custom_PropTest );
}

#endif
void Register_UnityEngine_Test_get_anotherTest()
{
	mono_add_internal_call( "UnityEngine.Test::get_anotherTest" , (gpointer)& Test_Get_Custom_PropAnotherTest );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_TwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditions_IcallNames [] =
{
#if UNITY_XENON_API
	"UnityEngine.Test::get_test"            ,	// -> Test_Get_Custom_PropTest
#endif
	"UnityEngine.Test::get_anotherTest"     ,	// -> Test_Get_Custom_PropAnotherTest
	NULL
};

static const void* s_TwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditions_IcallFuncs [] =
{
#if UNITY_XENON_API
	(const void*)&Test_Get_Custom_PropTest                ,	//  <- UnityEngine.Test::get_test
#endif
	(const void*)&Test_Get_Custom_PropAnotherTest         ,	//  <- UnityEngine.Test::get_anotherTest
	NULL
};

void ExportTwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditionsBindings();
void ExportTwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditionsBindings()
{
	for (int i = 0; s_TwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditions_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_TwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditions_IcallNames [i], s_TwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditions_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportTwoBlocksOneConditionalOneObsolete_SucceedsWithFlushConditionsBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
#if UNITY_XENON_API
	SET_METRO_BINDING(Test_Get_Custom_PropTest);	//  <- UnityEngine.Test::get_test
#endif
	SET_METRO_BINDING(Test_Get_Custom_PropAnotherTest);	//  <- UnityEngine.Test::get_anotherTest
}

#endif
