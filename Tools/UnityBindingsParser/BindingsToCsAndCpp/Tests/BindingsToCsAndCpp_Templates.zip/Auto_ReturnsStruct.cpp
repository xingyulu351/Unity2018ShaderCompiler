SCRIPT_BINDINGS_EXPORT_DECL
Vector3f SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_CALL_EnsureQuaternionContinuity(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_EnsureQuaternionContinuity)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_CALL_EnsureQuaternionContinuity)
	return self->EnsureQuaternionContinuity();
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_MyClass_INTERNAL_CALL_EnsureQuaternionContinuity()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_CALL_EnsureQuaternionContinuity" , (gpointer)& MyClass_CUSTOM_INTERNAL_CALL_EnsureQuaternionContinuity );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Auto_ReturnsStruct_IcallNames [] =
{
	"UnityEngine.MyClass::INTERNAL_CALL_EnsureQuaternionContinuity",	// -> MyClass_CUSTOM_INTERNAL_CALL_EnsureQuaternionContinuity
	NULL
};

static const void* s_Auto_ReturnsStruct_IcallFuncs [] =
{
	(const void*)&MyClass_CUSTOM_INTERNAL_CALL_EnsureQuaternionContinuity,	//  <- UnityEngine.MyClass::INTERNAL_CALL_EnsureQuaternionContinuity
	NULL
};

void ExportAuto_ReturnsStructBindings();
void ExportAuto_ReturnsStructBindings()
{
	for (int i = 0; s_Auto_ReturnsStruct_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Auto_ReturnsStruct_IcallNames [i], s_Auto_ReturnsStruct_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportAuto_ReturnsStructBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_CALL_EnsureQuaternionContinuity);	//  <- UnityEngine.MyClass::INTERNAL_CALL_EnsureQuaternionContinuity
}

#endif
