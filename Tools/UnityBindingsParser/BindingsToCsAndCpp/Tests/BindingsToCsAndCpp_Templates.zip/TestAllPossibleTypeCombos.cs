using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	public extern  int intPropGetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern  int intPropGetterSetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	public extern  string stringPropGetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern  string stringPropGetterSetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	public extern  Vector3 Vector3PropGetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private  void INTERNAL_get_Vector3PropGetterSetter (out Vector3 value) ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private  void INTERNAL_set_Vector3PropGetterSetter (ref Vector3 value) ;

	public  Vector3 Vector3PropGetterSetter
	{
		get { Vector3 tmp; INTERNAL_get_Vector3PropGetterSetter(out tmp); return tmp;  }
		set { INTERNAL_set_Vector3PropGetterSetter(ref value); }
	}

	public extern static int static_intPropGetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	private extern  int private_intPropGetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	private extern static int private_static_intPropGetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	private extern static int static_private_intPropGetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern bool boolAuto
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern bool boolAutoGetterSetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	public extern string stringAuto
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern string stringAutoGetterSetter
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private void INTERNAL_get_vector3Auto (out Vector3 value) ;


	public Vector3 vector3Auto
	{
		get { Vector3 tmp; INTERNAL_get_vector3Auto(out tmp); return tmp;  }
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private void INTERNAL_get_vector3AutoGetterSetter (out Vector3 value) ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private void INTERNAL_set_vector3AutoGetterSetter (ref Vector3 value) ;

	public Vector3 vector3AutoGetterSetter
	{
		get { Vector3 tmp; INTERNAL_get_vector3AutoGetterSetter(out tmp); return tmp;  }
		set { INTERNAL_set_vector3AutoGetterSetter(ref value); }
	}

	public extern Flare flarePtr
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	public extern Flare flare
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	public extern bool boolAutoPtr
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern bool boolAutoGetterSetterPtr
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	public extern string stringAutoPtr
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern string stringAutoGetterSetterPtr
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	public extern Vector3 vector3AutoPtr
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	public extern Vector3 vector3AutoGetterSetterPtr
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public int intMethod () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public string stringMethod () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public IntPtr IntPtrMethod () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public Vector3 Vector3Method () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  int static_intMethod () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private int private_intMethod () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private static  int private_static_intMethod () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private static  int static_private_intMethod () ;

	public void voidMethodVector3 (Vector3 a1) {
		INTERNAL_CALL_voidMethodVector3 ( this, ref a1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_voidMethodVector3 (MyClass self, ref Vector3 a1);
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void voidMethodVector3Out (out Vector3 a1) ;

	public void voidMethodVector3Ref (ref Vector3 a1) {
		INTERNAL_CALL_voidMethodVector3Ref ( this, ref a1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_voidMethodVector3Ref (MyClass self, ref Vector3 a1);
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void voidMethodVector3OutIntOut (out Vector3 a1, out int b) ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void voidMethodVector3OutVector3Out (out Vector3 a1, out Vector3 b) ;

	public void voidMethodVector3RefVector3Ref (ref Vector3 a1, ref Vector3 b) {
		INTERNAL_CALL_voidMethodVector3RefVector3Ref ( this, ref a1, ref b );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_voidMethodVector3RefVector3Ref (MyClass self, ref Vector3 a1, ref Vector3 b);
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void voidMethodWritableObject ([Writable]Object rhs) ;

	public static void staticvoidMethodVector3 (Vector3 a1) {
		INTERNAL_CALL_staticvoidMethodVector3 ( ref a1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_staticvoidMethodVector3 (ref Vector3 a1);
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  void StaticVoidMethodStringDef ( [uei.DefaultValue("\"\"")] string argDef1 ) ;

	[uei.ExcludeFromDocs]
	public static void StaticVoidMethodStringDef () {
		string argDef1 = "";
		StaticVoidMethodStringDef ( argDef1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  void StaticVoidMethodStringStringDef (string arg1, [uei.DefaultValue("\"\"")]  string argDef1 ) ;

	[uei.ExcludeFromDocs]
	public static void StaticVoidMethodStringStringDef (string arg1) {
		string argDef1 = "";
		StaticVoidMethodStringStringDef ( arg1, argDef1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  void StaticVoidMethodStringStringDefStringDef (string arg1, [uei.DefaultValue("\"\"")]  string argDef1 , [uei.DefaultValue("\"\"")]  string argDef2 ) ;

	[uei.ExcludeFromDocs]
	public static void StaticVoidMethodStringStringDefStringDef (string arg1, string argDef1 ) {
		string argDef2 = "";
		StaticVoidMethodStringStringDefStringDef ( arg1, argDef1, argDef2 );
	}

	[uei.ExcludeFromDocs]
	public static void StaticVoidMethodStringStringDefStringDef (string arg1) {
		string argDef2 = "";
		string argDef1 = "";
		StaticVoidMethodStringStringDefStringDef ( arg1, argDef1, argDef2 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  void StaticVoidMethodStringStringStringDef (string arg1, [uei.DefaultValue("\"\"")]  string argDef1 ) ;

	[uei.ExcludeFromDocs]
	public static void StaticVoidMethodStringStringStringDef (string arg1) {
		string argDef1 = "";
		StaticVoidMethodStringStringStringDef ( arg1, argDef1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  IntPtr SafeIntPtrMethodIntPtrStringDef (IntPtr javaClass, [uei.DefaultValue("\"\"")]  string signature ) ;

	[uei.ExcludeFromDocs]
	public static IntPtr SafeIntPtrMethodIntPtrStringDef (IntPtr javaClass) {
		string signature = "";
		return SafeIntPtrMethodIntPtrStringDef ( javaClass, signature );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  IntPtr IntPtrMethodIntPtrStringDef (IntPtr javaClass, [uei.DefaultValue("\"\"")]  string signature ) ;

	[uei.ExcludeFromDocs]
	public static IntPtr IntPtrMethodIntPtrStringDef (IntPtr javaClass) {
		string signature = "";
		return IntPtrMethodIntPtrStringDef ( javaClass, signature );
	}

	public void SafevoidMethodVector3 (Vector3 a1) {
		INTERNAL_CALL_SafevoidMethodVector3 ( this, ref a1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_SafevoidMethodVector3 (MyClass self, ref Vector3 a1);
}

