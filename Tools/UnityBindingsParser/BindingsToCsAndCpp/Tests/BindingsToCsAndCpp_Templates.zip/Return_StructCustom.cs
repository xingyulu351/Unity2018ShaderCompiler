using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public Vector3 GetVector3 () ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  int GetInt () ;

}

