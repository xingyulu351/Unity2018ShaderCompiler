using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private  void INTERNAL_get_GetSetVector3 (out Vector3 value) ;

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private  void INTERNAL_set_GetSetVector3 (ref Vector3 value) ;

	public  Vector3 GetSetVector3
	{
		get { Vector3 tmp; INTERNAL_get_GetSetVector3(out tmp); return tmp;  }
		set { INTERNAL_set_GetSetVector3(ref value); }
	}

	public extern static int GetInt
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

