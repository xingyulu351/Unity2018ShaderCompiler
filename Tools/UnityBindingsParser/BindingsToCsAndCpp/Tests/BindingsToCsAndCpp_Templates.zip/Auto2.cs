using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Camera
{
	public void EnsureQuaternionContinuity () {
		INTERNAL_CALL_EnsureQuaternionContinuity ( this );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_EnsureQuaternionContinuity (Camera self);
}

