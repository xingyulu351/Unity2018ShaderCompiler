using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class AnimationCurve
{
	public bool isMouse {
		get { EventType t = type; return t == EventType.MouseMove || t == EventType.MouseDown  || t == EventType.MouseUp || t == EventType.MouseDrag; }
	}
		
	public static Event KeyboardEvent (string key) {
		Event evt = new Event ();
		evt.type = EventType.KeyDown;
		if (key == null || key == String.Empty)
			return evt;
#if !UNITY_WEBGL
		int startIdx = 0;
		bool found = false;
		do {
			switch (key[startIdx]) {
			default:
				found = false;
				break;
			}
		} while (found);
		string subStr = key.Substring (startIdx, key.Length - startIdx).ToLower();
#endif
		return evt;
	}
}

