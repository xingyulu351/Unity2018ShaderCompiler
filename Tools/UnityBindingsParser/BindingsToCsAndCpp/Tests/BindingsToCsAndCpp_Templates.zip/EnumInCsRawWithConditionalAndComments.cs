using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
#if UNITY_XENON_API

public enum X360AchievementType : uint
{
	Completion = 1,
	Leveling,
	Unlock,
	Event,
	Tournament,
	Checkpoint,
	Other
}

#endif
