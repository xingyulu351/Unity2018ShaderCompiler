
#include "UnityPrefix.h"
#if UNITY_ANDROID || UNITY_EDITOR
SCRIPT_BINDINGS_EXPORT_DECL
Touch SCRIPT_CALL_CONVENTION AndroidInput_CUSTOM_GetSecondaryTouch(int index)
{
	SCRIPTINGAPI_STACK_CHECK(GetSecondaryTouch)
	SCRIPTINGAPI_THREAD_CHECK(GetSecondaryTouch)
	
			Touch touch;
			return touch;
		
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION AndroidInput_Get_Custom_PropTouchCountSecondary()
{
	SCRIPTINGAPI_STACK_CHECK(get_touchCountSecondary)
	SCRIPTINGAPI_THREAD_CHECK(get_touchCountSecondary)
	return 0;
}

#endif
#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
#if UNITY_ANDROID || UNITY_EDITOR
void Register_UnityEngine_AndroidInput_GetSecondaryTouch()
{
	mono_add_internal_call( "UnityEngine.AndroidInput::GetSecondaryTouch" , (gpointer)& AndroidInput_CUSTOM_GetSecondaryTouch );
}

void Register_UnityEngine_AndroidInput_get_touchCountSecondary()
{
	mono_add_internal_call( "UnityEngine.AndroidInput::get_touchCountSecondary" , (gpointer)& AndroidInput_Get_Custom_PropTouchCountSecondary );
}

#endif
#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Conditionals2_IcallNames [] =
{
#if UNITY_ANDROID || UNITY_EDITOR
	"UnityEngine.AndroidInput::GetSecondaryTouch",	// -> AndroidInput_CUSTOM_GetSecondaryTouch
	"UnityEngine.AndroidInput::get_touchCountSecondary",	// -> AndroidInput_Get_Custom_PropTouchCountSecondary
#endif
	NULL
};

static const void* s_Conditionals2_IcallFuncs [] =
{
#if UNITY_ANDROID || UNITY_EDITOR
	(const void*)&AndroidInput_CUSTOM_GetSecondaryTouch   ,	//  <- UnityEngine.AndroidInput::GetSecondaryTouch
	(const void*)&AndroidInput_Get_Custom_PropTouchCountSecondary,	//  <- UnityEngine.AndroidInput::get_touchCountSecondary
#endif
	NULL
};

void ExportConditionals2Bindings();
void ExportConditionals2Bindings()
{
	for (int i = 0; s_Conditionals2_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Conditionals2_IcallNames [i], s_Conditionals2_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportConditionals2Bindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
#if UNITY_ANDROID || UNITY_EDITOR
	SET_METRO_BINDING(AndroidInput_CUSTOM_GetSecondaryTouch);	//  <- UnityEngine.AndroidInput::GetSecondaryTouch
	SET_METRO_BINDING(AndroidInput_Get_Custom_PropTouchCountSecondary);	//  <- UnityEngine.AndroidInput::get_touchCountSecondary
#endif
}

#endif
