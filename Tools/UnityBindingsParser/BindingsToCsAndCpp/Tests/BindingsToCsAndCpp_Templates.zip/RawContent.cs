using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
internal sealed partial class ScrollViewState
{
	static internal void CheckOnGUI() {
		}
		
	internal extern static bool mouseUsed
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		set;
	}

	
		
		static internal Vector2 s_EditorScreenPointOffset = Vector2.zero;
		static internal bool s_HasKeyboardFocus = false;
}

