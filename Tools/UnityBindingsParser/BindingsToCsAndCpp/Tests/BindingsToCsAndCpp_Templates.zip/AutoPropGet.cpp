SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropIsReadable(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_isReadable)
	SCRIPTINGAPI_THREAD_CHECK(get_isReadable)
	return self->GetIsReadable ();
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_MyClass_get_isReadable()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_isReadable" , (gpointer)& MyClass_Get_Custom_PropIsReadable );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_AutoPropGet_IcallNames [] =
{
	"UnityEngine.MyClass::get_isReadable"   ,	// -> MyClass_Get_Custom_PropIsReadable
	NULL
};

static const void* s_AutoPropGet_IcallFuncs [] =
{
	(const void*)&MyClass_Get_Custom_PropIsReadable       ,	//  <- UnityEngine.MyClass::get_isReadable
	NULL
};

void ExportAutoPropGetBindings();
void ExportAutoPropGetBindings()
{
	for (int i = 0; s_AutoPropGet_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_AutoPropGet_IcallNames [i], s_AutoPropGet_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportAutoPropGetBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(MyClass_Get_Custom_PropIsReadable);	//  <- UnityEngine.MyClass::get_isReadable
}

#endif
