
#include "UnityPrefix.h"
SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION Matrix4x4_Get_Custom_PropIsIdentity(Matrix4x4f self)
{
	SCRIPTINGAPI_STACK_CHECK(get_isIdentity)
	return self.IsIdentity();
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Matrix4x4_get_isIdentity()
{
	mono_add_internal_call( "UnityEngine.Matrix4x4::get_isIdentity" , (gpointer)& Matrix4x4_Get_Custom_PropIsIdentity );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_TypeMapping_Matrix4x4AsStruct_IcallNames [] =
{
	"UnityEngine.Matrix4x4::get_isIdentity" ,	// -> Matrix4x4_Get_Custom_PropIsIdentity
	NULL
};

static const void* s_TypeMapping_Matrix4x4AsStruct_IcallFuncs [] =
{
	(const void*)&Matrix4x4_Get_Custom_PropIsIdentity     ,	//  <- UnityEngine.Matrix4x4::get_isIdentity
	NULL
};

void ExportTypeMapping_Matrix4x4AsStructBindings();
void ExportTypeMapping_Matrix4x4AsStructBindings()
{
	for (int i = 0; s_TypeMapping_Matrix4x4AsStruct_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_TypeMapping_Matrix4x4AsStruct_IcallNames [i], s_TypeMapping_Matrix4x4AsStruct_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportTypeMapping_Matrix4x4AsStructBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Matrix4x4_Get_Custom_PropIsIdentity);	//  <- UnityEngine.Matrix4x4::get_isIdentity
}

#endif
