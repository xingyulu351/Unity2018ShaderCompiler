using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
#if UNITY_ANDROID || UNITY_EDITOR
public sealed partial class AndroidInput
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  Touch GetSecondaryTouch (int index) ;

	public extern static int touchCountSecondary
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

#endif
