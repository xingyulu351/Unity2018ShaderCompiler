SCRIPT_BINDINGS_EXPORT_DECL
Vector3f SCRIPT_CALL_CONVENTION Camera_CUSTOM_GetVector3(ReadOnlyScriptingObjectOfType<Camera> self)
{
	SCRIPTINGAPI_STACK_CHECK(GetVector3)
	SCRIPTINGAPI_THREAD_CHECK(GetVector3)
	
			return 0;
		
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_CUSTOM_GetInt()
{
	SCRIPTINGAPI_STACK_CHECK(GetInt)
	SCRIPTINGAPI_THREAD_CHECK(GetInt)
	
			return 0;
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_GetVector3()
{
	mono_add_internal_call( "UnityEngine.Camera::GetVector3" , (gpointer)& Camera_CUSTOM_GetVector3 );
}

void Register_UnityEngine_Camera_GetInt()
{
	mono_add_internal_call( "UnityEngine.Camera::GetInt" , (gpointer)& Camera_CUSTOM_GetInt );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Return_StructCustom_IcallNames [] =
{
	"UnityEngine.Camera::GetVector3"        ,	// -> Camera_CUSTOM_GetVector3
	"UnityEngine.Camera::GetInt"            ,	// -> Camera_CUSTOM_GetInt
	NULL
};

static const void* s_Return_StructCustom_IcallFuncs [] =
{
	(const void*)&Camera_CUSTOM_GetVector3                ,	//  <- UnityEngine.Camera::GetVector3
	(const void*)&Camera_CUSTOM_GetInt                    ,	//  <- UnityEngine.Camera::GetInt
	NULL
};

void ExportReturn_StructCustomBindings();
void ExportReturn_StructCustomBindings()
{
	for (int i = 0; s_Return_StructCustom_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Return_StructCustom_IcallNames [i], s_Return_StructCustom_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportReturn_StructCustomBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_CUSTOM_GetVector3);	//  <- UnityEngine.Camera::GetVector3
	SET_METRO_BINDING(Camera_CUSTOM_GetInt);	//  <- UnityEngine.Camera::GetInt
}

#endif
