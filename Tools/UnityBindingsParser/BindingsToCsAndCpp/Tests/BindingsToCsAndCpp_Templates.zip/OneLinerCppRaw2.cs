using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Unsupported
{
	internal static Vector3 MakeNiceVector3 (Vector3 vector) {
		return INTERNAL_CALL_MakeNiceVector3 ( ref vector );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static Vector3 INTERNAL_CALL_MakeNiceVector3 (ref Vector3 vector);
}

}
