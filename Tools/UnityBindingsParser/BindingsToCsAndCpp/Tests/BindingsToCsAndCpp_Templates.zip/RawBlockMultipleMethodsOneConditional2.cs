using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Test
{
#if UNITY_XENON_API
	public static string Method1() {
		return null;
	}
#endif
	
	public static string Method2() {
		return null;
	}
	
	
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public override static  string ToString () ;

}

