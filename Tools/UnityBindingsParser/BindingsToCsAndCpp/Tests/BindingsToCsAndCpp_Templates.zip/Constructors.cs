using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class AnimationCurve
{
	public AnimationCurve (params Keyframe[] keys) { Init(keys); }
	
	
#if UNITY_FLASH || UNITY_METRO
	public AnimationCurve(IntPtr nativeptr) { m_Ptr = nativeptr; }
#endif
		
	public AnimationCurve ()  { Init(null); }
		
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern private void Init (Keyframe[] keys) ;

}

