using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
#if UNITY_XENON_API

public enum X360AchievementType : uint
{
	Completion = 1
}

#endif
#if UNITY_XENON_API
[StructLayout (LayoutKind.Sequential)]
public sealed partial class X360Achievement
{
}

#endif
#if UNITY_XENON_API
[StructLayout (LayoutKind.Sequential)]
public sealed partial class AnotherClass
{
}

#endif
