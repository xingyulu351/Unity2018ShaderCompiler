using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;


public sealed partial class Camera : Behaviour
{
	public float fov { get { return fieldOfView; } set { fieldOfView = value; } }
}

