SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION AnimationCurve_CUSTOM_Init(ScriptingObjectWithIntPtrField<AnimationCurve> self, ScriptingArrayPtr keys)
{
	SCRIPTINGAPI_STACK_CHECK(Init)
	
			self.SetPtr(new AnimationCurve());
			if (keys != SCRIPTING_NULL) AnimationCurve_CUSTOM_SetKeys(self, keys);
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_AnimationCurve_Init()
{
	mono_add_internal_call( "UnityEngine.AnimationCurve::Init" , (gpointer)& AnimationCurve_CUSTOM_Init );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Constructors_IcallNames [] =
{
	"UnityEngine.AnimationCurve::Init"      ,	// -> AnimationCurve_CUSTOM_Init
	NULL
};

static const void* s_Constructors_IcallFuncs [] =
{
	(const void*)&AnimationCurve_CUSTOM_Init              ,	//  <- UnityEngine.AnimationCurve::Init
	NULL
};

void ExportConstructorsBindings();
void ExportConstructorsBindings()
{
	for (int i = 0; s_Constructors_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Constructors_IcallNames [i], s_Constructors_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportConstructorsBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(AnimationCurve_CUSTOM_Init);	//  <- UnityEngine.AnimationCurve::Init
}

#endif
