using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEditor
{
public sealed partial class AnimationUtility
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  AnimationCurve GetEditorCurve (AnimationClip clip, string relativePath, Type type, string propertyName) ;

}

