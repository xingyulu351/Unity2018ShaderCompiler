#if ACONDITION
SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Class1_Get_Custom_PropMyProp1()
{
	SCRIPTINGAPI_STACK_CHECK(get_myProp1)
	SCRIPTINGAPI_THREAD_CHECK(get_myProp1)
	return 0;
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Class2_Get_Custom_PropMyProp2()
{
	SCRIPTINGAPI_STACK_CHECK(get_myProp2)
	SCRIPTINGAPI_THREAD_CHECK(get_myProp2)
	return 0;
}

#endif
#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
#if ACONDITION
void Register_UnityEngine_Class1_get_myProp1()
{
	mono_add_internal_call( "UnityEngine.Class1::get_myProp1" , (gpointer)& Class1_Get_Custom_PropMyProp1 );
}

void Register_UnityEngine_Class2_get_myProp2()
{
	mono_add_internal_call( "UnityEngine.Class2::get_myProp2" , (gpointer)& Class2_Get_Custom_PropMyProp2 );
}

#endif
#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_SameConditionalInTwoClasses_IcallNames [] =
{
#if ACONDITION
	"UnityEngine.Class1::get_myProp1"       ,	// -> Class1_Get_Custom_PropMyProp1
	"UnityEngine.Class2::get_myProp2"       ,	// -> Class2_Get_Custom_PropMyProp2
#endif
	NULL
};

static const void* s_SameConditionalInTwoClasses_IcallFuncs [] =
{
#if ACONDITION
	(const void*)&Class1_Get_Custom_PropMyProp1           ,	//  <- UnityEngine.Class1::get_myProp1
	(const void*)&Class2_Get_Custom_PropMyProp2           ,	//  <- UnityEngine.Class2::get_myProp2
#endif
	NULL
};

void ExportSameConditionalInTwoClassesBindings();
void ExportSameConditionalInTwoClassesBindings()
{
	for (int i = 0; s_SameConditionalInTwoClasses_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_SameConditionalInTwoClasses_IcallNames [i], s_SameConditionalInTwoClasses_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportSameConditionalInTwoClassesBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
#if ACONDITION
	SET_METRO_BINDING(Class1_Get_Custom_PropMyProp1);	//  <- UnityEngine.Class1::get_myProp1
	SET_METRO_BINDING(Class2_Get_Custom_PropMyProp2);	//  <- UnityEngine.Class2::get_myProp2
#endif
}

#endif
