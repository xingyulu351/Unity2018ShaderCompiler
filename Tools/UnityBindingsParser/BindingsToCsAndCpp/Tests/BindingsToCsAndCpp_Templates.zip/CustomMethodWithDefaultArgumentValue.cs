using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  IntPtr GetConstructorID (IntPtr javaClass, [uei.DefaultValue("\"\"")]  string signature ) ;

	[uei.ExcludeFromDocs]
	public static IntPtr GetConstructorID (IntPtr javaClass) {
		string signature = "";
		return GetConstructorID ( javaClass, signature );
	}

}

