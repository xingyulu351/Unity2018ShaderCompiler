using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	public Vector3 EnsureQuaternionContinuity () {
		return INTERNAL_CALL_EnsureQuaternionContinuity ( this );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static Vector3 INTERNAL_CALL_EnsureQuaternionContinuity (MyClass self);
}

