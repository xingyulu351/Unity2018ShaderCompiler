using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Unsupported
{
	public extern static bool imeIsSelected
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

}
