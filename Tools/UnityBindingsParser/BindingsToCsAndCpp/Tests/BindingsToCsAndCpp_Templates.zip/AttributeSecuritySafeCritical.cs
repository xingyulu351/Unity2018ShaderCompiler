using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class TerrainRenderer
{
	
		[System.Security.SecuritySafeCritical] 
	public void SetData (System.Array data) {
		InternalSetData (data, Marshal.SizeOf(data.GetType().GetElementType()));
	}
}

