using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public static  IntPtr GetConstructorID (IntPtr javaClass, [uei.DefaultValue("\"\"")]  string signature , [uei.DefaultValue("2")]  int another ) ;

	[uei.ExcludeFromDocs]
	public static IntPtr GetConstructorID (IntPtr javaClass, string signature ) {
		int another = 2;
		return GetConstructorID ( javaClass, signature, another );
	}

	[uei.ExcludeFromDocs]
	public static IntPtr GetConstructorID (IntPtr javaClass) {
		int another = 2;
		string signature = "";
		return GetConstructorID ( javaClass, signature, another );
	}

}

