using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	public extern int getStringUTFChars
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

