SCRIPT_BINDINGS_EXPORT_DECL
void* SCRIPT_CALL_CONVENTION Camera_CUSTOM_GetConstructorID(void* javaClass, ICallString signature)
{
	SCRIPTINGAPI_STACK_CHECK(GetConstructorID)
	SCRIPTINGAPI_THREAD_CHECK(GetConstructorID)
	
			a++;
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_GetConstructorID()
{
	mono_add_internal_call( "UnityEngine.Camera::GetConstructorID" , (gpointer)& Camera_CUSTOM_GetConstructorID );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomMethodWithDefaultArgumentValue_IcallNames [] =
{
	"UnityEngine.Camera::GetConstructorID"  ,	// -> Camera_CUSTOM_GetConstructorID
	NULL
};

static const void* s_CustomMethodWithDefaultArgumentValue_IcallFuncs [] =
{
	(const void*)&Camera_CUSTOM_GetConstructorID          ,	//  <- UnityEngine.Camera::GetConstructorID
	NULL
};

void ExportCustomMethodWithDefaultArgumentValueBindings();
void ExportCustomMethodWithDefaultArgumentValueBindings()
{
	for (int i = 0; s_CustomMethodWithDefaultArgumentValue_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomMethodWithDefaultArgumentValue_IcallNames [i], s_CustomMethodWithDefaultArgumentValue_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomMethodWithDefaultArgumentValueBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_CUSTOM_GetConstructorID);	//  <- UnityEngine.Camera::GetConstructorID
}

#endif
