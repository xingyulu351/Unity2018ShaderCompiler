using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class TerrainRenderer
{
	public  TerrainRenderer (int instanceID, TerrainData terrainData, Vector3 position, int lightmapIndex) {
		INTERNAL_CALL_TerrainRenderer ( this, instanceID, terrainData, ref position, lightmapIndex );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_TerrainRenderer (TerrainRenderer self, int instanceID, TerrainData terrainData, ref Vector3 position, int lightmapIndex);
}

