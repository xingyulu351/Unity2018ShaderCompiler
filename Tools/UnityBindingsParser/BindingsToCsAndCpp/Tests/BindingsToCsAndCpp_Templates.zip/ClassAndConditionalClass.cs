using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern internal void SetParameter () ;

}

#if UNITY_EDITOR
internal sealed partial class HumanTrait : Object
{
	public extern static int MuscleCount
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

#endif
