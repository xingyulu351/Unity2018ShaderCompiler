SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION AnimationUtility_CUSTOM_GetEditorCurve(ReadOnlyScriptingObjectOfType<AnimationClip> clip, ICallString relativePath, ScriptingSystemTypeObjectPtr type, ICallString propertyName)
{
	SCRIPTINGAPI_STACK_CHECK(GetEditorCurve)
	SCRIPTINGAPI_THREAD_CHECK(GetEditorCurve)
	
			return null;
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEditor_AnimationUtility_GetEditorCurve()
{
	mono_add_internal_call( "UnityEditor.AnimationUtility::GetEditorCurve" , (gpointer)& AnimationUtility_CUSTOM_GetEditorCurve );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Return_StructCustomObject_IcallNames [] =
{
	"UnityEditor.AnimationUtility::GetEditorCurve",	// -> AnimationUtility_CUSTOM_GetEditorCurve
	NULL
};

static const void* s_Return_StructCustomObject_IcallFuncs [] =
{
	(const void*)&AnimationUtility_CUSTOM_GetEditorCurve  ,	//  <- UnityEditor.AnimationUtility::GetEditorCurve
	NULL
};

void ExportReturn_StructCustomObjectBindings();
void ExportReturn_StructCustomObjectBindings()
{
	for (int i = 0; s_Return_StructCustomObject_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Return_StructCustomObject_IcallNames [i], s_Return_StructCustomObject_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportReturn_StructCustomObjectBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(AnimationUtility_CUSTOM_GetEditorCurve);	//  <- UnityEditor.AnimationUtility::GetEditorCurve
}

#endif
