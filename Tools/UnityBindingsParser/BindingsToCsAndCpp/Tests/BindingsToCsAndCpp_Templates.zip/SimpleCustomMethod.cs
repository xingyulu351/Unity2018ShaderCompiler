using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEditor.One.Two.Three {
{
public sealed partial class Camera : Behaviour
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void MyMethod () ;

}

