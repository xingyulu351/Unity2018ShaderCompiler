using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public abstract sealed partial class PropertyAttribute : Attribute
{
}

