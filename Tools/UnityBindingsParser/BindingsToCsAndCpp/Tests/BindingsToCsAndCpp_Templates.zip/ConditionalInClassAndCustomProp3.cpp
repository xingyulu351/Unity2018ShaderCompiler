#if ACONDITION
SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropMyProp()
{
	SCRIPTINGAPI_STACK_CHECK(get_myProp)
	SCRIPTINGAPI_THREAD_CHECK(get_myProp)
	return 0;
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropMyProp2()
{
	SCRIPTINGAPI_STACK_CHECK(get_myProp2)
	SCRIPTINGAPI_THREAD_CHECK(get_myProp2)
	return 0;
}

#endif
#if (ACONDITION) && (ANOTHERCONDITION)
SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropMyProp3()
{
	SCRIPTINGAPI_STACK_CHECK(get_myProp3)
	SCRIPTINGAPI_THREAD_CHECK(get_myProp3)
	return 0;
}

#endif
#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
#if ACONDITION
void Register_UnityEngine_Camera_get_myProp()
{
	mono_add_internal_call( "UnityEngine.Camera::get_myProp" , (gpointer)& Camera_Get_Custom_PropMyProp );
}

void Register_UnityEngine_Camera_get_myProp2()
{
	mono_add_internal_call( "UnityEngine.Camera::get_myProp2" , (gpointer)& Camera_Get_Custom_PropMyProp2 );
}

#endif
#if (ACONDITION) && (ANOTHERCONDITION)
void Register_UnityEngine_Camera_get_myProp3()
{
	mono_add_internal_call( "UnityEngine.Camera::get_myProp3" , (gpointer)& Camera_Get_Custom_PropMyProp3 );
}

#endif
#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_ConditionalInClassAndCustomProp3_IcallNames [] =
{
#if ACONDITION
	"UnityEngine.Camera::get_myProp"        ,	// -> Camera_Get_Custom_PropMyProp
	"UnityEngine.Camera::get_myProp2"       ,	// -> Camera_Get_Custom_PropMyProp2
#endif
#if (ACONDITION) && (ANOTHERCONDITION)
	"UnityEngine.Camera::get_myProp3"       ,	// -> Camera_Get_Custom_PropMyProp3
#endif
	NULL
};

static const void* s_ConditionalInClassAndCustomProp3_IcallFuncs [] =
{
#if ACONDITION
	(const void*)&Camera_Get_Custom_PropMyProp            ,	//  <- UnityEngine.Camera::get_myProp
	(const void*)&Camera_Get_Custom_PropMyProp2           ,	//  <- UnityEngine.Camera::get_myProp2
#endif
#if (ACONDITION) && (ANOTHERCONDITION)
	(const void*)&Camera_Get_Custom_PropMyProp3           ,	//  <- UnityEngine.Camera::get_myProp3
#endif
	NULL
};

void ExportConditionalInClassAndCustomProp3Bindings();
void ExportConditionalInClassAndCustomProp3Bindings()
{
	for (int i = 0; s_ConditionalInClassAndCustomProp3_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_ConditionalInClassAndCustomProp3_IcallNames [i], s_ConditionalInClassAndCustomProp3_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportConditionalInClassAndCustomProp3Bindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
#if ACONDITION
	SET_METRO_BINDING(Camera_Get_Custom_PropMyProp);	//  <- UnityEngine.Camera::get_myProp
	SET_METRO_BINDING(Camera_Get_Custom_PropMyProp2);	//  <- UnityEngine.Camera::get_myProp2
#endif
#if (ACONDITION) && (ANOTHERCONDITION)
	SET_METRO_BINDING(Camera_Get_Custom_PropMyProp3);	//  <- UnityEngine.Camera::get_myProp3
#endif
}

#endif
