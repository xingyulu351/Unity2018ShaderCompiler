using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
public sealed partial class Camera : Behaviour
{
	
	static void LoadScriptInfos () {
		string tipStrings = System.IO.File.ReadAllText (EditorApplication.applicationContentsPath + "/Resources/UI_Strings_EN.txt");
		foreach (string tip in tipStrings.Split ('\n')) {
			if (tip.StartsWith("//"))
				continue;
		}
	}
}

