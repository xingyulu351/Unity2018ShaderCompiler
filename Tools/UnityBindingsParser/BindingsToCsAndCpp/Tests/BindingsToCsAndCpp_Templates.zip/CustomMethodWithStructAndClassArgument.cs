using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Camera : Behaviour
{
	public static void MyMethod (Vector3 v, Texture2D tex) {
		INTERNAL_CALL_MyMethod ( ref v, tex );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_MyMethod (ref Vector3 v, Texture2D tex);
}

