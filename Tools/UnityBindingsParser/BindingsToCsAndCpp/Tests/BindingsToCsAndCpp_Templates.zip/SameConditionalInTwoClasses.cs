using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

namespace UnityEngine
{
#if ACONDITION
public sealed partial class Class1
{
	public extern static int myProp1
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

#endif
#if ACONDITION
public sealed partial class Class2
{
	public extern static int myProp2
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

}

#endif
