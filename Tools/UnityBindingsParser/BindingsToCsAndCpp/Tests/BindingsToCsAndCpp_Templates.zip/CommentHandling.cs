using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Unsupported
{
#if UNITY_XENON_API
	[StructLayout(LayoutKind.Explicit)]
	public struct X360AvatarShaderParamData
	{
		[FieldOffset(0)]
				public Vector4 Float4;
	}

#endif
}

}
