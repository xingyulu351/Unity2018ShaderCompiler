using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	public void EnsureQuaternionContinuity (bool arg1) {
		INTERNAL_CALL_EnsureQuaternionContinuity ( this, arg1 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_EnsureQuaternionContinuity (MyClass self, bool arg1);
}

