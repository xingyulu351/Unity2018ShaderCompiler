using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public enum TextureFormat
{
	DXT5 = 12,
}

