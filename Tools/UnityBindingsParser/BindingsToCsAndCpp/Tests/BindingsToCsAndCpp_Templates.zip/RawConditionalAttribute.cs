using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
#if ENABLE_NETWORK
[AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
public sealed partial class RPC : Attribute
{
}

#endif
