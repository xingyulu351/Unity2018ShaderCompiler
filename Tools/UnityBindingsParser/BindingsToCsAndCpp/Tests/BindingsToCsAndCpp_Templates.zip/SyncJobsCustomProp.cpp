SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION TestClass_Get_Custom_PropMyCustomProp(ReadOnlyScriptingObjectOfType<TestClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_myCustomProp)
	SCRIPTINGAPI_THREAD_CHECK(get_myCustomProp)
	return true;
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_TestClass_get_myCustomProp()
{
	mono_add_internal_call( "UnityEngine.TestClass::get_myCustomProp" , (gpointer)& TestClass_Get_Custom_PropMyCustomProp );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_SyncJobsCustomProp_IcallNames [] =
{
	"UnityEngine.TestClass::get_myCustomProp",	// -> TestClass_Get_Custom_PropMyCustomProp
	NULL
};

static const void* s_SyncJobsCustomProp_IcallFuncs [] =
{
	(const void*)&TestClass_Get_Custom_PropMyCustomProp   ,	//  <- UnityEngine.TestClass::get_myCustomProp
	NULL
};

void ExportSyncJobsCustomPropBindings();
void ExportSyncJobsCustomPropBindings()
{
	for (int i = 0; s_SyncJobsCustomProp_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_SyncJobsCustomProp_IcallNames [i], s_SyncJobsCustomProp_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportSyncJobsCustomPropBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(TestClass_Get_Custom_PropMyCustomProp);	//  <- UnityEngine.TestClass::get_myCustomProp
}

#endif
