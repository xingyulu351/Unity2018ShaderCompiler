SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropMyProp()
{
	SCRIPTINGAPI_STACK_CHECK(get_myProp)
	SCRIPTINGAPI_THREAD_CHECK(get_myProp)
	return 0;
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION Camera_Set_Custom_PropMyProp(int value)
{
	SCRIPTINGAPI_STACK_CHECK(set_myProp)
	SCRIPTINGAPI_THREAD_CHECK(set_myProp)
	
	
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_get_myProp()
{
	mono_add_internal_call( "UnityEngine.Camera::get_myProp" , (gpointer)& Camera_Get_Custom_PropMyProp );
}

void Register_UnityEngine_Camera_set_myProp()
{
	mono_add_internal_call( "UnityEngine.Camera::set_myProp" , (gpointer)& Camera_Set_Custom_PropMyProp );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomPropGetterSetter_IcallNames [] =
{
	"UnityEngine.Camera::get_myProp"        ,	// -> Camera_Get_Custom_PropMyProp
	"UnityEngine.Camera::set_myProp"        ,	// -> Camera_Set_Custom_PropMyProp
	NULL
};

static const void* s_CustomPropGetterSetter_IcallFuncs [] =
{
	(const void*)&Camera_Get_Custom_PropMyProp            ,	//  <- UnityEngine.Camera::get_myProp
	(const void*)&Camera_Set_Custom_PropMyProp            ,	//  <- UnityEngine.Camera::set_myProp
	NULL
};

void ExportCustomPropGetterSetterBindings();
void ExportCustomPropGetterSetterBindings()
{
	for (int i = 0; s_CustomPropGetterSetter_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomPropGetterSetter_IcallNames [i], s_CustomPropGetterSetter_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomPropGetterSetterBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_Get_Custom_PropMyProp);	//  <- UnityEngine.Camera::get_myProp
	SET_METRO_BINDING(Camera_Set_Custom_PropMyProp);	//  <- UnityEngine.Camera::set_myProp
}

#endif
