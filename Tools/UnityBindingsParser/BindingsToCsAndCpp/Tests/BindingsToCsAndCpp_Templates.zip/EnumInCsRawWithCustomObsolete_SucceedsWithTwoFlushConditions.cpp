SCRIPT_BINDINGS_EXPORT_DECL
float SCRIPT_CALL_CONVENTION Test_Get_Custom_PropFrameRate(ReadOnlyScriptingObjectOfType<Test> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_frameRate)
	SCRIPTINGAPI_THREAD_CHECK(get_frameRate)
	return self->GetSampleRate ();
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Test_get_frameRate()
{
	mono_add_internal_call( "UnityEngine.Test::get_frameRate" , (gpointer)& Test_Get_Custom_PropFrameRate );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_EnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditions_IcallNames [] =
{
	"UnityEngine.Test::get_frameRate"       ,	// -> Test_Get_Custom_PropFrameRate
	NULL
};

static const void* s_EnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditions_IcallFuncs [] =
{
	(const void*)&Test_Get_Custom_PropFrameRate           ,	//  <- UnityEngine.Test::get_frameRate
	NULL
};

void ExportEnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditionsBindings();
void ExportEnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditionsBindings()
{
	for (int i = 0; s_EnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditions_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_EnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditions_IcallNames [i], s_EnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditions_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportEnumInCsRawWithCustomObsolete_SucceedsWithTwoFlushConditionsBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Test_Get_Custom_PropFrameRate);	//  <- UnityEngine.Test::get_frameRate
}

#endif
