SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION aStruct_Get_Custom_PropIsIdentity(ReadOnlyScriptingObjectOfType<aStruct> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_isIdentity)
	SCRIPTINGAPI_THREAD_CHECK(get_isIdentity)
	return self.IsIdentity();
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION aStruct_Set_Custom_PropIsIdentity(ReadOnlyScriptingObjectOfType<aStruct> self, ScriptingBool value)
{
	SCRIPTINGAPI_STACK_CHECK(set_isIdentity)
	SCRIPTINGAPI_THREAD_CHECK(set_isIdentity)
	 self.SetIdentity(value); 
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_aStruct_get_isIdentity()
{
	mono_add_internal_call( "UnityEngine.aStruct::get_isIdentity" , (gpointer)& aStruct_Get_Custom_PropIsIdentity );
}

void Register_UnityEngine_aStruct_set_isIdentity()
{
	mono_add_internal_call( "UnityEngine.aStruct::set_isIdentity" , (gpointer)& aStruct_Set_Custom_PropIsIdentity );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_PropertiesInStructsWithSetter_IcallNames [] =
{
	"UnityEngine.aStruct::get_isIdentity"   ,	// -> aStruct_Get_Custom_PropIsIdentity
	"UnityEngine.aStruct::set_isIdentity"   ,	// -> aStruct_Set_Custom_PropIsIdentity
	NULL
};

static const void* s_PropertiesInStructsWithSetter_IcallFuncs [] =
{
	(const void*)&aStruct_Get_Custom_PropIsIdentity       ,	//  <- UnityEngine.aStruct::get_isIdentity
	(const void*)&aStruct_Set_Custom_PropIsIdentity       ,	//  <- UnityEngine.aStruct::set_isIdentity
	NULL
};

void ExportPropertiesInStructsWithSetterBindings();
void ExportPropertiesInStructsWithSetterBindings()
{
	for (int i = 0; s_PropertiesInStructsWithSetter_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_PropertiesInStructsWithSetter_IcallNames [i], s_PropertiesInStructsWithSetter_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportPropertiesInStructsWithSetterBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(aStruct_Get_Custom_PropIsIdentity);	//  <- UnityEngine.aStruct::get_isIdentity
	SET_METRO_BINDING(aStruct_Set_Custom_PropIsIdentity);	//  <- UnityEngine.aStruct::set_isIdentity
}

#endif
