using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class AnimationCurve
{
#if !UNITY_FLASH && !UNITY_WEBGL
	[System.Obsolete ("randomValue property is deprecated. Use randomSeed instead to control random behavior of particles.")]
	public float randomValue { get { return BitConverter.ToSingle(BitConverter.GetBytes(m_RandomSeed), 0); } set { m_RandomSeed = BitConverter.ToUInt32(BitConverter.GetBytes(value), 0); } }
#endif
}

