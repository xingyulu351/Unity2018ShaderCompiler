using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class TerrainRenderer
{
	public void SetHeights (int xBase, int yBase, float[,] heights) {
			a++
		}
}

