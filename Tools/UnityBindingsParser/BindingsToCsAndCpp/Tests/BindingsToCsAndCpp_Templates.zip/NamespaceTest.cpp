SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION Test_CUSTOM_Test1(ReadOnlyScriptingObjectOfType<Test> self)
{
	SCRIPTINGAPI_STACK_CHECK(Test1)
	SCRIPTINGAPI_THREAD_CHECK(Test1)
	
		
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION Camera_CUSTOM_MyMethod(ReadOnlyScriptingObjectOfType<Camera> self)
{
	SCRIPTINGAPI_STACK_CHECK(MyMethod)
	SCRIPTINGAPI_THREAD_CHECK(MyMethod)
	
		
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEditor_Test_Test1()
{
	mono_add_internal_call( "UnityEditor.Test::Test1" , (gpointer)& Test_CUSTOM_Test1 );
}

void Register_UnityEditorInternal_Camera_MyMethod()
{
	mono_add_internal_call( "UnityEditorInternal.Camera::MyMethod" , (gpointer)& Camera_CUSTOM_MyMethod );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_NamespaceTest_IcallNames [] =
{
	"UnityEditor.Test::Test1"               ,	// -> Test_CUSTOM_Test1
	"UnityEditorInternal.Camera::MyMethod"  ,	// -> Camera_CUSTOM_MyMethod
	NULL
};

static const void* s_NamespaceTest_IcallFuncs [] =
{
	(const void*)&Test_CUSTOM_Test1                       ,	//  <- UnityEditor.Test::Test1
	(const void*)&Camera_CUSTOM_MyMethod                  ,	//  <- UnityEditorInternal.Camera::MyMethod
	NULL
};

void ExportNamespaceTestBindings();
void ExportNamespaceTestBindings()
{
	for (int i = 0; s_NamespaceTest_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_NamespaceTest_IcallNames [i], s_NamespaceTest_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportNamespaceTestBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Test_CUSTOM_Test1);	//  <- UnityEditor.Test::Test1
	SET_METRO_BINDING(Camera_CUSTOM_MyMethod);	//  <- UnityEditorInternal.Camera::MyMethod
}

#endif
