SCRIPT_BINDINGS_EXPORT_DECL
float SCRIPT_CALL_CONVENTION Unsupported_Get_Custom_PropRecorderStartTime(ReadOnlyScriptingObjectOfType<Unsupported> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_recorderStartTime)
	SCRIPTINGAPI_THREAD_CHECK(get_recorderStartTime)
	return self->GetRecorderStartTime();
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION Unsupported_Set_Custom_PropRecorderStartTime(ReadOnlyScriptingObjectOfType<Unsupported> self, float value)
{
	SCRIPTINGAPI_STACK_CHECK(set_recorderStartTime)
	SCRIPTINGAPI_THREAD_CHECK(set_recorderStartTime)
	
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Unsupported_get_recorderStartTime()
{
	mono_add_internal_call( "UnityEngine.Unsupported::get_recorderStartTime" , (gpointer)& Unsupported_Get_Custom_PropRecorderStartTime );
}

void Register_UnityEngine_Unsupported_set_recorderStartTime()
{
	mono_add_internal_call( "UnityEngine.Unsupported::set_recorderStartTime" , (gpointer)& Unsupported_Set_Custom_PropRecorderStartTime );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_CustomPropWithGetterAndEmptySetter_IcallNames [] =
{
	"UnityEngine.Unsupported::get_recorderStartTime",	// -> Unsupported_Get_Custom_PropRecorderStartTime
	"UnityEngine.Unsupported::set_recorderStartTime",	// -> Unsupported_Set_Custom_PropRecorderStartTime
	NULL
};

static const void* s_CustomPropWithGetterAndEmptySetter_IcallFuncs [] =
{
	(const void*)&Unsupported_Get_Custom_PropRecorderStartTime,	//  <- UnityEngine.Unsupported::get_recorderStartTime
	(const void*)&Unsupported_Set_Custom_PropRecorderStartTime,	//  <- UnityEngine.Unsupported::set_recorderStartTime
	NULL
};

void ExportCustomPropWithGetterAndEmptySetterBindings();
void ExportCustomPropWithGetterAndEmptySetterBindings()
{
	for (int i = 0; s_CustomPropWithGetterAndEmptySetter_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_CustomPropWithGetterAndEmptySetter_IcallNames [i], s_CustomPropWithGetterAndEmptySetter_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportCustomPropWithGetterAndEmptySetterBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Unsupported_Get_Custom_PropRecorderStartTime);	//  <- UnityEngine.Unsupported::get_recorderStartTime
	SET_METRO_BINDING(Unsupported_Set_Custom_PropRecorderStartTime);	//  <- UnityEngine.Unsupported::set_recorderStartTime
}

#endif
