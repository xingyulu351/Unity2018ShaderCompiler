SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION TerrainRenderer_CUSTOM_INTERNAL_CALL_TerrainRenderer(ReadOnlyScriptingObjectOfType<TerrainRenderer> self, int instanceID, ReadOnlyScriptingObjectOfType<TerrainData> terrainData, const Vector3f& position, int lightmapIndex)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_TerrainRenderer)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_CALL_TerrainRenderer)
	
				TerrainRenderer* t = new TerrainRenderer(instanceID, terrainData, position, lightmapIndex);
				MarshallNativeStructIntoManaged(t, self);
			
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_TerrainRenderer_INTERNAL_CALL_TerrainRenderer()
{
	mono_add_internal_call( "UnityEngine.TerrainRenderer::INTERNAL_CALL_TerrainRenderer" , (gpointer)& TerrainRenderer_CUSTOM_INTERNAL_CALL_TerrainRenderer );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_ClassWithConstructorWithStructArg_IcallNames [] =
{
	"UnityEngine.TerrainRenderer::INTERNAL_CALL_TerrainRenderer",	// -> TerrainRenderer_CUSTOM_INTERNAL_CALL_TerrainRenderer
	NULL
};

static const void* s_ClassWithConstructorWithStructArg_IcallFuncs [] =
{
	(const void*)&TerrainRenderer_CUSTOM_INTERNAL_CALL_TerrainRenderer,	//  <- UnityEngine.TerrainRenderer::INTERNAL_CALL_TerrainRenderer
	NULL
};

void ExportClassWithConstructorWithStructArgBindings();
void ExportClassWithConstructorWithStructArgBindings()
{
	for (int i = 0; s_ClassWithConstructorWithStructArg_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_ClassWithConstructorWithStructArg_IcallNames [i], s_ClassWithConstructorWithStructArg_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportClassWithConstructorWithStructArgBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(TerrainRenderer_CUSTOM_INTERNAL_CALL_TerrainRenderer);	//  <- UnityEngine.TerrainRenderer::INTERNAL_CALL_TerrainRenderer
}

#endif
