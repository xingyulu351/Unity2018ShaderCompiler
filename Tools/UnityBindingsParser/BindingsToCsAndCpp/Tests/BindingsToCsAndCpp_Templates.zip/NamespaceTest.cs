using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEditor {
public sealed partial class Test
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void Test1 () ;

}

}
namespace UnityEditorInternal {
public sealed partial class Camera : Behaviour
{
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public void MyMethod () ;

}

}
