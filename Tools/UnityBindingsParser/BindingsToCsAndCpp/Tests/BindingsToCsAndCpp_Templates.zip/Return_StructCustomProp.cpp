SCRIPT_BINDINGS_EXPORT_DECL
Vector3f SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropGetSetVector3(ReadOnlyScriptingObjectOfType<Camera> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_GetSetVector3)
	SCRIPTINGAPI_THREAD_CHECK(get_GetSetVector3)
	return 0;
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION Camera_Get_Custom_PropGetInt()
{
	SCRIPTINGAPI_STACK_CHECK(get_GetInt)
	SCRIPTINGAPI_THREAD_CHECK(get_GetInt)
	return 0;
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_Camera_get_GetSetVector3()
{
	mono_add_internal_call( "UnityEngine.Camera::get_GetSetVector3" , (gpointer)& Camera_Get_Custom_PropGetSetVector3 );
}

void Register_UnityEngine_Camera_get_GetInt()
{
	mono_add_internal_call( "UnityEngine.Camera::get_GetInt" , (gpointer)& Camera_Get_Custom_PropGetInt );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_Return_StructCustomProp_IcallNames [] =
{
	"UnityEngine.Camera::get_GetSetVector3" ,	// -> Camera_Get_Custom_PropGetSetVector3
	"UnityEngine.Camera::get_GetInt"        ,	// -> Camera_Get_Custom_PropGetInt
	NULL
};

static const void* s_Return_StructCustomProp_IcallFuncs [] =
{
	(const void*)&Camera_Get_Custom_PropGetSetVector3     ,	//  <- UnityEngine.Camera::get_GetSetVector3
	(const void*)&Camera_Get_Custom_PropGetInt            ,	//  <- UnityEngine.Camera::get_GetInt
	NULL
};

void ExportReturn_StructCustomPropBindings();
void ExportReturn_StructCustomPropBindings()
{
	for (int i = 0; s_Return_StructCustomProp_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_Return_StructCustomProp_IcallNames [i], s_Return_StructCustomProp_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportReturn_StructCustomPropBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(Camera_Get_Custom_PropGetSetVector3);	//  <- UnityEngine.Camera::get_GetSetVector3
	SET_METRO_BINDING(Camera_Get_Custom_PropGetInt);	//  <- UnityEngine.Camera::get_GetInt
}

#endif
