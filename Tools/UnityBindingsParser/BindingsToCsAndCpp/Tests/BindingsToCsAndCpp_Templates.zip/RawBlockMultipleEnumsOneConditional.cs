using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class Test
{
#if UNITY_XENON_API
	public enum AnEnum : uint	
	{
		Completion = 1,
		Leveling
	}

#endif
	
	public enum AnotherEnum : uint	
	{
		Completion = 1,
		Leveling
	}

	
	
	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	extern public override static  string ToString () ;

}

