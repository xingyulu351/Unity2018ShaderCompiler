using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	public string EnsureQuaternionContinuity () {
		return INTERNAL_CALL_EnsureQuaternionContinuity ( this );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static string INTERNAL_CALL_EnsureQuaternionContinuity (MyClass self);
}

