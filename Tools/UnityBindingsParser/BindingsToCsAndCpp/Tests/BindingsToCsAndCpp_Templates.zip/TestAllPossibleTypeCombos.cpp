SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropIntPropGetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_intPropGetter)
	SCRIPTINGAPI_THREAD_CHECK(get_intPropGetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropIntPropGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_intPropGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(get_intPropGetterSetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropIntPropGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, int value)
{
	SCRIPTINGAPI_STACK_CHECK(set_intPropGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(set_intPropGetterSetter)
	 a = value; 
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingStringPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStringPropGetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_stringPropGetter)
	SCRIPTINGAPI_THREAD_CHECK(get_stringPropGetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingStringPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStringPropGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_stringPropGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(get_stringPropGetterSetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropStringPropGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, ICallString value)
{
	SCRIPTINGAPI_STACK_CHECK(set_stringPropGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(set_stringPropGetterSetter)
	 a = value; 
}

SCRIPT_BINDINGS_EXPORT_DECL
Vector3f SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropVector3PropGetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_Vector3PropGetter)
	SCRIPTINGAPI_THREAD_CHECK(get_Vector3PropGetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_get_Vector3PropGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f& value)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_get_Vector3PropGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_get_Vector3PropGetterSetter)
	{ value =(null); return;};
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_set_Vector3PropGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, const Vector3f& value)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_set_Vector3PropGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_set_Vector3PropGetterSetter)
	 a = value; 
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStatic_intPropGetter()
{
	SCRIPTINGAPI_STACK_CHECK(get_static_intPropGetter)
	SCRIPTINGAPI_THREAD_CHECK(get_static_intPropGetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropPrivate_intPropGetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_private_intPropGetter)
	SCRIPTINGAPI_THREAD_CHECK(get_private_intPropGetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropPrivate_static_intPropGetter()
{
	SCRIPTINGAPI_STACK_CHECK(get_private_static_intPropGetter)
	SCRIPTINGAPI_THREAD_CHECK(get_private_static_intPropGetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStatic_private_intPropGetter()
{
	SCRIPTINGAPI_STACK_CHECK(get_static_private_intPropGetter)
	SCRIPTINGAPI_THREAD_CHECK(get_static_private_intPropGetter)
	return null;
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropBoolAuto(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_boolAuto)
	SCRIPTINGAPI_THREAD_CHECK(get_boolAuto)
	return self->BoolAuto ();
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingBool SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropBoolAutoGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_boolAutoGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(get_boolAutoGetterSetter)
	return self->BoolAutoGetter ();
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropBoolAutoGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, ScriptingBool value)
{
	SCRIPTINGAPI_STACK_CHECK(set_boolAutoGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(set_boolAutoGetterSetter)
	
	self->BoolAutoSetter (value);
	
}

SCRIPT_BINDINGS_EXPORT_DECL
ICallString SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStringAuto(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_stringAuto)
	SCRIPTINGAPI_THREAD_CHECK(get_stringAuto)
	return self->StringAuto ();
}

SCRIPT_BINDINGS_EXPORT_DECL
ICallString SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStringAutoGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_stringAutoGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(get_stringAutoGetterSetter)
	return self->GetStringAuto ();
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropStringAutoGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, ICallString value)
{
	SCRIPTINGAPI_STACK_CHECK(set_stringAutoGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(set_stringAutoGetterSetter)
	
	self->SetStringAuto (value);
	
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_get_vector3Auto(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f& value)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_get_vector3Auto)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_get_vector3Auto)
	value = self->Vector3Auto();
	
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_get_vector3AutoGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f& value)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_get_vector3AutoGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_get_vector3AutoGetterSetter)
	value = self->GetVector3Auto();
	
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_set_vector3AutoGetterSetter(ReadOnlyScriptingObjectOfType<MyClass> self, const Vector3f& value)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_set_vector3AutoGetterSetter)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_set_vector3AutoGetterSetter)
	
	self->SetVector3Auto (value);
	
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropFlarePtr(ReadOnlyScriptingObjectOfType<MyClass> com)
{
	SCRIPTINGAPI_STACK_CHECK(get_flarePtr)
	SCRIPTINGAPI_THREAD_CHECK(get_flarePtr)
	return Scripting::ScriptingWrapperFor(com->GetFlarePtr());
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropFlarePtr(ReadOnlyScriptingObjectOfType<MyClass> com, ReadOnlyScriptingObjectOfType<Flare> val)
{
	SCRIPTINGAPI_STACK_CHECK(set_flarePtr)
	SCRIPTINGAPI_THREAD_CHECK(set_flarePtr)
	
	com->SetFlarePtr (val);
}

SCRIPT_BINDINGS_EXPORT_DECL
Flare SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropFlare(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(get_flare)
	SCRIPTINGAPI_THREAD_CHECK(get_flare)
	return self->GetFlare ();
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropFlare(ReadOnlyScriptingObjectOfType<MyClass> self, Flare value)
{
	SCRIPTINGAPI_STACK_CHECK(set_flare)
	SCRIPTINGAPI_THREAD_CHECK(set_flare)
	
	self->SetFlare (value);
	
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropBoolAutoPtr(ReadOnlyScriptingObjectOfType<MyClass> com)
{
	SCRIPTINGAPI_STACK_CHECK(get_boolAutoPtr)
	SCRIPTINGAPI_THREAD_CHECK(get_boolAutoPtr)
	return Scripting::ScriptingWrapperFor(com->BoolAutoPtr());
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropBoolAutoGetterSetterPtr(ReadOnlyScriptingObjectOfType<MyClass> com)
{
	SCRIPTINGAPI_STACK_CHECK(get_boolAutoGetterSetterPtr)
	SCRIPTINGAPI_THREAD_CHECK(get_boolAutoGetterSetterPtr)
	return Scripting::ScriptingWrapperFor(com->BoolAutoGetterPtr());
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropBoolAutoGetterSetterPtr(ReadOnlyScriptingObjectOfType<MyClass> com, ScriptingBool val)
{
	SCRIPTINGAPI_STACK_CHECK(set_boolAutoGetterSetterPtr)
	SCRIPTINGAPI_THREAD_CHECK(set_boolAutoGetterSetterPtr)
	
	com->BoolAutoSetterPtr (val);
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStringAutoPtr(ReadOnlyScriptingObjectOfType<MyClass> com)
{
	SCRIPTINGAPI_STACK_CHECK(get_stringAutoPtr)
	SCRIPTINGAPI_THREAD_CHECK(get_stringAutoPtr)
	return Scripting::ScriptingWrapperFor(com->StringAutoPtr());
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropStringAutoGetterSetterPtr(ReadOnlyScriptingObjectOfType<MyClass> com)
{
	SCRIPTINGAPI_STACK_CHECK(get_stringAutoGetterSetterPtr)
	SCRIPTINGAPI_THREAD_CHECK(get_stringAutoGetterSetterPtr)
	return Scripting::ScriptingWrapperFor(com->GetStringAutoPtr());
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropStringAutoGetterSetterPtr(ReadOnlyScriptingObjectOfType<MyClass> com, ICallString val)
{
	SCRIPTINGAPI_STACK_CHECK(set_stringAutoGetterSetterPtr)
	SCRIPTINGAPI_THREAD_CHECK(set_stringAutoGetterSetterPtr)
	
	com->SetStringAutoPtr (val);
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropVector3AutoPtr(ReadOnlyScriptingObjectOfType<MyClass> com)
{
	SCRIPTINGAPI_STACK_CHECK(get_vector3AutoPtr)
	SCRIPTINGAPI_THREAD_CHECK(get_vector3AutoPtr)
	return Scripting::ScriptingWrapperFor(com->Vector3AutoPtr());
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingObjectPtr SCRIPT_CALL_CONVENTION MyClass_Get_Custom_PropVector3AutoGetterSetterPtr(ReadOnlyScriptingObjectOfType<MyClass> com)
{
	SCRIPTINGAPI_STACK_CHECK(get_vector3AutoGetterSetterPtr)
	SCRIPTINGAPI_THREAD_CHECK(get_vector3AutoGetterSetterPtr)
	return Scripting::ScriptingWrapperFor(com->GetVector3AutoPtr());
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_Set_Custom_PropVector3AutoGetterSetterPtr(ReadOnlyScriptingObjectOfType<MyClass> com, Vector3f val)
{
	SCRIPTINGAPI_STACK_CHECK(set_vector3AutoGetterSetterPtr)
	SCRIPTINGAPI_THREAD_CHECK(set_vector3AutoGetterSetterPtr)
	
	com->SetVector3AutoPtr (val);
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_CUSTOM_intMethod(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(intMethod)
	SCRIPTINGAPI_THREAD_CHECK(intMethod)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
ScriptingStringPtr SCRIPT_CALL_CONVENTION MyClass_CUSTOM_stringMethod(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(stringMethod)
	SCRIPTINGAPI_THREAD_CHECK(stringMethod)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void* SCRIPT_CALL_CONVENTION MyClass_CUSTOM_IntPtrMethod(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(IntPtrMethod)
	SCRIPTINGAPI_THREAD_CHECK(IntPtrMethod)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
Vector3f SCRIPT_CALL_CONVENTION MyClass_CUSTOM_Vector3Method(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(Vector3Method)
	SCRIPTINGAPI_THREAD_CHECK(Vector3Method)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_CUSTOM_static_intMethod()
{
	SCRIPTINGAPI_STACK_CHECK(static_intMethod)
	SCRIPTINGAPI_THREAD_CHECK(static_intMethod)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_CUSTOM_private_intMethod(ReadOnlyScriptingObjectOfType<MyClass> self)
{
	SCRIPTINGAPI_STACK_CHECK(private_intMethod)
	SCRIPTINGAPI_THREAD_CHECK(private_intMethod)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_CUSTOM_private_static_intMethod()
{
	SCRIPTINGAPI_STACK_CHECK(private_static_intMethod)
	SCRIPTINGAPI_THREAD_CHECK(private_static_intMethod)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
int SCRIPT_CALL_CONVENTION MyClass_CUSTOM_static_private_intMethod()
{
	SCRIPTINGAPI_STACK_CHECK(static_private_intMethod)
	SCRIPTINGAPI_THREAD_CHECK(static_private_intMethod)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3(ReadOnlyScriptingObjectOfType<MyClass> self, const Vector3f& a1)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_voidMethodVector3)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_CALL_voidMethodVector3)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_voidMethodVector3Out(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f* a1)
{
	SCRIPTINGAPI_STACK_CHECK(voidMethodVector3Out)
	SCRIPTINGAPI_THREAD_CHECK(voidMethodVector3Out)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3Ref(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f& a1)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_voidMethodVector3Ref)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_CALL_voidMethodVector3Ref)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_voidMethodVector3OutIntOut(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f* a1, int* b)
{
	SCRIPTINGAPI_STACK_CHECK(voidMethodVector3OutIntOut)
	SCRIPTINGAPI_THREAD_CHECK(voidMethodVector3OutIntOut)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_voidMethodVector3OutVector3Out(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f* a1, Vector3f* b)
{
	SCRIPTINGAPI_STACK_CHECK(voidMethodVector3OutVector3Out)
	SCRIPTINGAPI_THREAD_CHECK(voidMethodVector3OutVector3Out)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3RefVector3Ref(ReadOnlyScriptingObjectOfType<MyClass> self, Vector3f& a1, Vector3f& b)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_voidMethodVector3RefVector3Ref)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_CALL_voidMethodVector3RefVector3Ref)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_voidMethodWritableObject(ReadOnlyScriptingObjectOfType<MyClass> self, ScriptingObjectOfType<Object> rhs)
{
	SCRIPTINGAPI_STACK_CHECK(voidMethodWritableObject)
	SCRIPTINGAPI_THREAD_CHECK(voidMethodWritableObject)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_CALL_staticvoidMethodVector3(const Vector3f& a1)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_staticvoidMethodVector3)
	SCRIPTINGAPI_THREAD_CHECK(INTERNAL_CALL_staticvoidMethodVector3)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_StaticVoidMethodStringDef(ICallString argDef1)
{
	SCRIPTINGAPI_STACK_CHECK(StaticVoidMethodStringDef)
	SCRIPTINGAPI_THREAD_CHECK(StaticVoidMethodStringDef)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_StaticVoidMethodStringStringDef(ICallString arg1, ICallString argDef1)
{
	SCRIPTINGAPI_STACK_CHECK(StaticVoidMethodStringStringDef)
	SCRIPTINGAPI_THREAD_CHECK(StaticVoidMethodStringStringDef)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_StaticVoidMethodStringStringDefStringDef(ICallString arg1, ICallString argDef1, ICallString argDef2)
{
	SCRIPTINGAPI_STACK_CHECK(StaticVoidMethodStringStringDefStringDef)
	SCRIPTINGAPI_THREAD_CHECK(StaticVoidMethodStringStringDefStringDef)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_StaticVoidMethodStringStringStringDef(ICallString arg1, ICallString argDef1)
{
	SCRIPTINGAPI_STACK_CHECK(StaticVoidMethodStringStringStringDef)
	SCRIPTINGAPI_THREAD_CHECK(StaticVoidMethodStringStringStringDef)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void* SCRIPT_CALL_CONVENTION MyClass_CUSTOM_SafeIntPtrMethodIntPtrStringDef(void* javaClass, ICallString signature)
{
	SCRIPTINGAPI_STACK_CHECK(SafeIntPtrMethodIntPtrStringDef)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void* SCRIPT_CALL_CONVENTION MyClass_CUSTOM_IntPtrMethodIntPtrStringDef(void* javaClass, ICallString signature)
{
	SCRIPTINGAPI_STACK_CHECK(IntPtrMethodIntPtrStringDef)
	SCRIPTINGAPI_THREAD_CHECK(IntPtrMethodIntPtrStringDef)
	 a++; 
}

SCRIPT_BINDINGS_EXPORT_DECL
void SCRIPT_CALL_CONVENTION MyClass_CUSTOM_INTERNAL_CALL_SafevoidMethodVector3(ReadOnlyScriptingObjectOfType<MyClass> self, const Vector3f& a1)
{
	SCRIPTINGAPI_STACK_CHECK(INTERNAL_CALL_SafevoidMethodVector3)
	 a++; 
}

#if !defined(INTERNAL_CALL_STRIPPING)
#	error must include unityconfigure.h
#endif
#if INTERNAL_CALL_STRIPPING
void Register_UnityEngine_MyClass_get_intPropGetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_intPropGetter" , (gpointer)& MyClass_Get_Custom_PropIntPropGetter );
}

void Register_UnityEngine_MyClass_get_intPropGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_intPropGetterSetter" , (gpointer)& MyClass_Get_Custom_PropIntPropGetterSetter );
}

void Register_UnityEngine_MyClass_set_intPropGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_intPropGetterSetter" , (gpointer)& MyClass_Set_Custom_PropIntPropGetterSetter );
}

void Register_UnityEngine_MyClass_get_stringPropGetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_stringPropGetter" , (gpointer)& MyClass_Get_Custom_PropStringPropGetter );
}

void Register_UnityEngine_MyClass_get_stringPropGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_stringPropGetterSetter" , (gpointer)& MyClass_Get_Custom_PropStringPropGetterSetter );
}

void Register_UnityEngine_MyClass_set_stringPropGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_stringPropGetterSetter" , (gpointer)& MyClass_Set_Custom_PropStringPropGetterSetter );
}

void Register_UnityEngine_MyClass_get_Vector3PropGetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_Vector3PropGetter" , (gpointer)& MyClass_Get_Custom_PropVector3PropGetter );
}

void Register_UnityEngine_MyClass_INTERNAL_get_Vector3PropGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_get_Vector3PropGetterSetter" , (gpointer)& MyClass_CUSTOM_INTERNAL_get_Vector3PropGetterSetter );
}

void Register_UnityEngine_MyClass_INTERNAL_set_Vector3PropGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_set_Vector3PropGetterSetter" , (gpointer)& MyClass_CUSTOM_INTERNAL_set_Vector3PropGetterSetter );
}

void Register_UnityEngine_MyClass_get_static_intPropGetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_static_intPropGetter" , (gpointer)& MyClass_Get_Custom_PropStatic_intPropGetter );
}

void Register_UnityEngine_MyClass_get_private_intPropGetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_private_intPropGetter" , (gpointer)& MyClass_Get_Custom_PropPrivate_intPropGetter );
}

void Register_UnityEngine_MyClass_get_private_static_intPropGetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_private_static_intPropGetter" , (gpointer)& MyClass_Get_Custom_PropPrivate_static_intPropGetter );
}

void Register_UnityEngine_MyClass_get_static_private_intPropGetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_static_private_intPropGetter" , (gpointer)& MyClass_Get_Custom_PropStatic_private_intPropGetter );
}

void Register_UnityEngine_MyClass_get_boolAuto()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_boolAuto" , (gpointer)& MyClass_Get_Custom_PropBoolAuto );
}

void Register_UnityEngine_MyClass_get_boolAutoGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_boolAutoGetterSetter" , (gpointer)& MyClass_Get_Custom_PropBoolAutoGetterSetter );
}

void Register_UnityEngine_MyClass_set_boolAutoGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_boolAutoGetterSetter" , (gpointer)& MyClass_Set_Custom_PropBoolAutoGetterSetter );
}

void Register_UnityEngine_MyClass_get_stringAuto()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_stringAuto" , (gpointer)& MyClass_Get_Custom_PropStringAuto );
}

void Register_UnityEngine_MyClass_get_stringAutoGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_stringAutoGetterSetter" , (gpointer)& MyClass_Get_Custom_PropStringAutoGetterSetter );
}

void Register_UnityEngine_MyClass_set_stringAutoGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_stringAutoGetterSetter" , (gpointer)& MyClass_Set_Custom_PropStringAutoGetterSetter );
}

void Register_UnityEngine_MyClass_INTERNAL_get_vector3Auto()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_get_vector3Auto" , (gpointer)& MyClass_CUSTOM_INTERNAL_get_vector3Auto );
}

void Register_UnityEngine_MyClass_INTERNAL_get_vector3AutoGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_get_vector3AutoGetterSetter" , (gpointer)& MyClass_CUSTOM_INTERNAL_get_vector3AutoGetterSetter );
}

void Register_UnityEngine_MyClass_INTERNAL_set_vector3AutoGetterSetter()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_set_vector3AutoGetterSetter" , (gpointer)& MyClass_CUSTOM_INTERNAL_set_vector3AutoGetterSetter );
}

void Register_UnityEngine_MyClass_get_flarePtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_flarePtr" , (gpointer)& MyClass_Get_Custom_PropFlarePtr );
}

void Register_UnityEngine_MyClass_set_flarePtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_flarePtr" , (gpointer)& MyClass_Set_Custom_PropFlarePtr );
}

void Register_UnityEngine_MyClass_get_flare()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_flare" , (gpointer)& MyClass_Get_Custom_PropFlare );
}

void Register_UnityEngine_MyClass_set_flare()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_flare" , (gpointer)& MyClass_Set_Custom_PropFlare );
}

void Register_UnityEngine_MyClass_get_boolAutoPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_boolAutoPtr" , (gpointer)& MyClass_Get_Custom_PropBoolAutoPtr );
}

void Register_UnityEngine_MyClass_get_boolAutoGetterSetterPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_boolAutoGetterSetterPtr" , (gpointer)& MyClass_Get_Custom_PropBoolAutoGetterSetterPtr );
}

void Register_UnityEngine_MyClass_set_boolAutoGetterSetterPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_boolAutoGetterSetterPtr" , (gpointer)& MyClass_Set_Custom_PropBoolAutoGetterSetterPtr );
}

void Register_UnityEngine_MyClass_get_stringAutoPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_stringAutoPtr" , (gpointer)& MyClass_Get_Custom_PropStringAutoPtr );
}

void Register_UnityEngine_MyClass_get_stringAutoGetterSetterPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_stringAutoGetterSetterPtr" , (gpointer)& MyClass_Get_Custom_PropStringAutoGetterSetterPtr );
}

void Register_UnityEngine_MyClass_set_stringAutoGetterSetterPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_stringAutoGetterSetterPtr" , (gpointer)& MyClass_Set_Custom_PropStringAutoGetterSetterPtr );
}

void Register_UnityEngine_MyClass_get_vector3AutoPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_vector3AutoPtr" , (gpointer)& MyClass_Get_Custom_PropVector3AutoPtr );
}

void Register_UnityEngine_MyClass_get_vector3AutoGetterSetterPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::get_vector3AutoGetterSetterPtr" , (gpointer)& MyClass_Get_Custom_PropVector3AutoGetterSetterPtr );
}

void Register_UnityEngine_MyClass_set_vector3AutoGetterSetterPtr()
{
	mono_add_internal_call( "UnityEngine.MyClass::set_vector3AutoGetterSetterPtr" , (gpointer)& MyClass_Set_Custom_PropVector3AutoGetterSetterPtr );
}

void Register_UnityEngine_MyClass_intMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::intMethod" , (gpointer)& MyClass_CUSTOM_intMethod );
}

void Register_UnityEngine_MyClass_stringMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::stringMethod" , (gpointer)& MyClass_CUSTOM_stringMethod );
}

void Register_UnityEngine_MyClass_IntPtrMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::IntPtrMethod" , (gpointer)& MyClass_CUSTOM_IntPtrMethod );
}

void Register_UnityEngine_MyClass_Vector3Method()
{
	mono_add_internal_call( "UnityEngine.MyClass::Vector3Method" , (gpointer)& MyClass_CUSTOM_Vector3Method );
}

void Register_UnityEngine_MyClass_static_intMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::static_intMethod" , (gpointer)& MyClass_CUSTOM_static_intMethod );
}

void Register_UnityEngine_MyClass_private_intMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::private_intMethod" , (gpointer)& MyClass_CUSTOM_private_intMethod );
}

void Register_UnityEngine_MyClass_private_static_intMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::private_static_intMethod" , (gpointer)& MyClass_CUSTOM_private_static_intMethod );
}

void Register_UnityEngine_MyClass_static_private_intMethod()
{
	mono_add_internal_call( "UnityEngine.MyClass::static_private_intMethod" , (gpointer)& MyClass_CUSTOM_static_private_intMethod );
}

void Register_UnityEngine_MyClass_INTERNAL_CALL_voidMethodVector3()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3" , (gpointer)& MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3 );
}

void Register_UnityEngine_MyClass_voidMethodVector3Out()
{
	mono_add_internal_call( "UnityEngine.MyClass::voidMethodVector3Out" , (gpointer)& MyClass_CUSTOM_voidMethodVector3Out );
}

void Register_UnityEngine_MyClass_INTERNAL_CALL_voidMethodVector3Ref()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3Ref" , (gpointer)& MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3Ref );
}

void Register_UnityEngine_MyClass_voidMethodVector3OutIntOut()
{
	mono_add_internal_call( "UnityEngine.MyClass::voidMethodVector3OutIntOut" , (gpointer)& MyClass_CUSTOM_voidMethodVector3OutIntOut );
}

void Register_UnityEngine_MyClass_voidMethodVector3OutVector3Out()
{
	mono_add_internal_call( "UnityEngine.MyClass::voidMethodVector3OutVector3Out" , (gpointer)& MyClass_CUSTOM_voidMethodVector3OutVector3Out );
}

void Register_UnityEngine_MyClass_INTERNAL_CALL_voidMethodVector3RefVector3Ref()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3RefVector3Ref" , (gpointer)& MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3RefVector3Ref );
}

void Register_UnityEngine_MyClass_voidMethodWritableObject()
{
	mono_add_internal_call( "UnityEngine.MyClass::voidMethodWritableObject" , (gpointer)& MyClass_CUSTOM_voidMethodWritableObject );
}

void Register_UnityEngine_MyClass_INTERNAL_CALL_staticvoidMethodVector3()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_CALL_staticvoidMethodVector3" , (gpointer)& MyClass_CUSTOM_INTERNAL_CALL_staticvoidMethodVector3 );
}

void Register_UnityEngine_MyClass_StaticVoidMethodStringDef()
{
	mono_add_internal_call( "UnityEngine.MyClass::StaticVoidMethodStringDef" , (gpointer)& MyClass_CUSTOM_StaticVoidMethodStringDef );
}

void Register_UnityEngine_MyClass_StaticVoidMethodStringStringDef()
{
	mono_add_internal_call( "UnityEngine.MyClass::StaticVoidMethodStringStringDef" , (gpointer)& MyClass_CUSTOM_StaticVoidMethodStringStringDef );
}

void Register_UnityEngine_MyClass_StaticVoidMethodStringStringDefStringDef()
{
	mono_add_internal_call( "UnityEngine.MyClass::StaticVoidMethodStringStringDefStringDef" , (gpointer)& MyClass_CUSTOM_StaticVoidMethodStringStringDefStringDef );
}

void Register_UnityEngine_MyClass_StaticVoidMethodStringStringStringDef()
{
	mono_add_internal_call( "UnityEngine.MyClass::StaticVoidMethodStringStringStringDef" , (gpointer)& MyClass_CUSTOM_StaticVoidMethodStringStringStringDef );
}

void Register_UnityEngine_MyClass_SafeIntPtrMethodIntPtrStringDef()
{
	mono_add_internal_call( "UnityEngine.MyClass::SafeIntPtrMethodIntPtrStringDef" , (gpointer)& MyClass_CUSTOM_SafeIntPtrMethodIntPtrStringDef );
}

void Register_UnityEngine_MyClass_IntPtrMethodIntPtrStringDef()
{
	mono_add_internal_call( "UnityEngine.MyClass::IntPtrMethodIntPtrStringDef" , (gpointer)& MyClass_CUSTOM_IntPtrMethodIntPtrStringDef );
}

void Register_UnityEngine_MyClass_INTERNAL_CALL_SafevoidMethodVector3()
{
	mono_add_internal_call( "UnityEngine.MyClass::INTERNAL_CALL_SafevoidMethodVector3" , (gpointer)& MyClass_CUSTOM_INTERNAL_CALL_SafevoidMethodVector3 );
}

#elif ENABLE_MONO || ENABLE_IL2CPP
static const char* s_TestAllPossibleTypeCombos_IcallNames [] =
{
	"UnityEngine.MyClass::get_intPropGetter",	// -> MyClass_Get_Custom_PropIntPropGetter
	"UnityEngine.MyClass::get_intPropGetterSetter",	// -> MyClass_Get_Custom_PropIntPropGetterSetter
	"UnityEngine.MyClass::set_intPropGetterSetter",	// -> MyClass_Set_Custom_PropIntPropGetterSetter
	"UnityEngine.MyClass::get_stringPropGetter",	// -> MyClass_Get_Custom_PropStringPropGetter
	"UnityEngine.MyClass::get_stringPropGetterSetter",	// -> MyClass_Get_Custom_PropStringPropGetterSetter
	"UnityEngine.MyClass::set_stringPropGetterSetter",	// -> MyClass_Set_Custom_PropStringPropGetterSetter
	"UnityEngine.MyClass::get_Vector3PropGetter",	// -> MyClass_Get_Custom_PropVector3PropGetter
	"UnityEngine.MyClass::INTERNAL_get_Vector3PropGetterSetter",	// -> MyClass_CUSTOM_INTERNAL_get_Vector3PropGetterSetter
	"UnityEngine.MyClass::INTERNAL_set_Vector3PropGetterSetter",	// -> MyClass_CUSTOM_INTERNAL_set_Vector3PropGetterSetter
	"UnityEngine.MyClass::get_static_intPropGetter",	// -> MyClass_Get_Custom_PropStatic_intPropGetter
	"UnityEngine.MyClass::get_private_intPropGetter",	// -> MyClass_Get_Custom_PropPrivate_intPropGetter
	"UnityEngine.MyClass::get_private_static_intPropGetter",	// -> MyClass_Get_Custom_PropPrivate_static_intPropGetter
	"UnityEngine.MyClass::get_static_private_intPropGetter",	// -> MyClass_Get_Custom_PropStatic_private_intPropGetter
	"UnityEngine.MyClass::get_boolAuto"     ,	// -> MyClass_Get_Custom_PropBoolAuto
	"UnityEngine.MyClass::get_boolAutoGetterSetter",	// -> MyClass_Get_Custom_PropBoolAutoGetterSetter
	"UnityEngine.MyClass::set_boolAutoGetterSetter",	// -> MyClass_Set_Custom_PropBoolAutoGetterSetter
	"UnityEngine.MyClass::get_stringAuto"   ,	// -> MyClass_Get_Custom_PropStringAuto
	"UnityEngine.MyClass::get_stringAutoGetterSetter",	// -> MyClass_Get_Custom_PropStringAutoGetterSetter
	"UnityEngine.MyClass::set_stringAutoGetterSetter",	// -> MyClass_Set_Custom_PropStringAutoGetterSetter
	"UnityEngine.MyClass::INTERNAL_get_vector3Auto",	// -> MyClass_CUSTOM_INTERNAL_get_vector3Auto
	"UnityEngine.MyClass::INTERNAL_get_vector3AutoGetterSetter",	// -> MyClass_CUSTOM_INTERNAL_get_vector3AutoGetterSetter
	"UnityEngine.MyClass::INTERNAL_set_vector3AutoGetterSetter",	// -> MyClass_CUSTOM_INTERNAL_set_vector3AutoGetterSetter
	"UnityEngine.MyClass::get_flarePtr"     ,	// -> MyClass_Get_Custom_PropFlarePtr
	"UnityEngine.MyClass::set_flarePtr"     ,	// -> MyClass_Set_Custom_PropFlarePtr
	"UnityEngine.MyClass::get_flare"        ,	// -> MyClass_Get_Custom_PropFlare
	"UnityEngine.MyClass::set_flare"        ,	// -> MyClass_Set_Custom_PropFlare
	"UnityEngine.MyClass::get_boolAutoPtr"  ,	// -> MyClass_Get_Custom_PropBoolAutoPtr
	"UnityEngine.MyClass::get_boolAutoGetterSetterPtr",	// -> MyClass_Get_Custom_PropBoolAutoGetterSetterPtr
	"UnityEngine.MyClass::set_boolAutoGetterSetterPtr",	// -> MyClass_Set_Custom_PropBoolAutoGetterSetterPtr
	"UnityEngine.MyClass::get_stringAutoPtr",	// -> MyClass_Get_Custom_PropStringAutoPtr
	"UnityEngine.MyClass::get_stringAutoGetterSetterPtr",	// -> MyClass_Get_Custom_PropStringAutoGetterSetterPtr
	"UnityEngine.MyClass::set_stringAutoGetterSetterPtr",	// -> MyClass_Set_Custom_PropStringAutoGetterSetterPtr
	"UnityEngine.MyClass::get_vector3AutoPtr",	// -> MyClass_Get_Custom_PropVector3AutoPtr
	"UnityEngine.MyClass::get_vector3AutoGetterSetterPtr",	// -> MyClass_Get_Custom_PropVector3AutoGetterSetterPtr
	"UnityEngine.MyClass::set_vector3AutoGetterSetterPtr",	// -> MyClass_Set_Custom_PropVector3AutoGetterSetterPtr
	"UnityEngine.MyClass::intMethod"        ,	// -> MyClass_CUSTOM_intMethod
	"UnityEngine.MyClass::stringMethod"     ,	// -> MyClass_CUSTOM_stringMethod
	"UnityEngine.MyClass::IntPtrMethod"     ,	// -> MyClass_CUSTOM_IntPtrMethod
	"UnityEngine.MyClass::Vector3Method"    ,	// -> MyClass_CUSTOM_Vector3Method
	"UnityEngine.MyClass::static_intMethod" ,	// -> MyClass_CUSTOM_static_intMethod
	"UnityEngine.MyClass::private_intMethod",	// -> MyClass_CUSTOM_private_intMethod
	"UnityEngine.MyClass::private_static_intMethod",	// -> MyClass_CUSTOM_private_static_intMethod
	"UnityEngine.MyClass::static_private_intMethod",	// -> MyClass_CUSTOM_static_private_intMethod
	"UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3",	// -> MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3
	"UnityEngine.MyClass::voidMethodVector3Out",	// -> MyClass_CUSTOM_voidMethodVector3Out
	"UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3Ref",	// -> MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3Ref
	"UnityEngine.MyClass::voidMethodVector3OutIntOut",	// -> MyClass_CUSTOM_voidMethodVector3OutIntOut
	"UnityEngine.MyClass::voidMethodVector3OutVector3Out",	// -> MyClass_CUSTOM_voidMethodVector3OutVector3Out
	"UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3RefVector3Ref",	// -> MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3RefVector3Ref
	"UnityEngine.MyClass::voidMethodWritableObject",	// -> MyClass_CUSTOM_voidMethodWritableObject
	"UnityEngine.MyClass::INTERNAL_CALL_staticvoidMethodVector3",	// -> MyClass_CUSTOM_INTERNAL_CALL_staticvoidMethodVector3
	"UnityEngine.MyClass::StaticVoidMethodStringDef",	// -> MyClass_CUSTOM_StaticVoidMethodStringDef
	"UnityEngine.MyClass::StaticVoidMethodStringStringDef",	// -> MyClass_CUSTOM_StaticVoidMethodStringStringDef
	"UnityEngine.MyClass::StaticVoidMethodStringStringDefStringDef",	// -> MyClass_CUSTOM_StaticVoidMethodStringStringDefStringDef
	"UnityEngine.MyClass::StaticVoidMethodStringStringStringDef",	// -> MyClass_CUSTOM_StaticVoidMethodStringStringStringDef
	"UnityEngine.MyClass::SafeIntPtrMethodIntPtrStringDef",	// -> MyClass_CUSTOM_SafeIntPtrMethodIntPtrStringDef
	"UnityEngine.MyClass::IntPtrMethodIntPtrStringDef",	// -> MyClass_CUSTOM_IntPtrMethodIntPtrStringDef
	"UnityEngine.MyClass::INTERNAL_CALL_SafevoidMethodVector3",	// -> MyClass_CUSTOM_INTERNAL_CALL_SafevoidMethodVector3
	NULL
};

static const void* s_TestAllPossibleTypeCombos_IcallFuncs [] =
{
	(const void*)&MyClass_Get_Custom_PropIntPropGetter    ,	//  <- UnityEngine.MyClass::get_intPropGetter
	(const void*)&MyClass_Get_Custom_PropIntPropGetterSetter,	//  <- UnityEngine.MyClass::get_intPropGetterSetter
	(const void*)&MyClass_Set_Custom_PropIntPropGetterSetter,	//  <- UnityEngine.MyClass::set_intPropGetterSetter
	(const void*)&MyClass_Get_Custom_PropStringPropGetter ,	//  <- UnityEngine.MyClass::get_stringPropGetter
	(const void*)&MyClass_Get_Custom_PropStringPropGetterSetter,	//  <- UnityEngine.MyClass::get_stringPropGetterSetter
	(const void*)&MyClass_Set_Custom_PropStringPropGetterSetter,	//  <- UnityEngine.MyClass::set_stringPropGetterSetter
	(const void*)&MyClass_Get_Custom_PropVector3PropGetter,	//  <- UnityEngine.MyClass::get_Vector3PropGetter
	(const void*)&MyClass_CUSTOM_INTERNAL_get_Vector3PropGetterSetter,	//  <- UnityEngine.MyClass::INTERNAL_get_Vector3PropGetterSetter
	(const void*)&MyClass_CUSTOM_INTERNAL_set_Vector3PropGetterSetter,	//  <- UnityEngine.MyClass::INTERNAL_set_Vector3PropGetterSetter
	(const void*)&MyClass_Get_Custom_PropStatic_intPropGetter,	//  <- UnityEngine.MyClass::get_static_intPropGetter
	(const void*)&MyClass_Get_Custom_PropPrivate_intPropGetter,	//  <- UnityEngine.MyClass::get_private_intPropGetter
	(const void*)&MyClass_Get_Custom_PropPrivate_static_intPropGetter,	//  <- UnityEngine.MyClass::get_private_static_intPropGetter
	(const void*)&MyClass_Get_Custom_PropStatic_private_intPropGetter,	//  <- UnityEngine.MyClass::get_static_private_intPropGetter
	(const void*)&MyClass_Get_Custom_PropBoolAuto         ,	//  <- UnityEngine.MyClass::get_boolAuto
	(const void*)&MyClass_Get_Custom_PropBoolAutoGetterSetter,	//  <- UnityEngine.MyClass::get_boolAutoGetterSetter
	(const void*)&MyClass_Set_Custom_PropBoolAutoGetterSetter,	//  <- UnityEngine.MyClass::set_boolAutoGetterSetter
	(const void*)&MyClass_Get_Custom_PropStringAuto       ,	//  <- UnityEngine.MyClass::get_stringAuto
	(const void*)&MyClass_Get_Custom_PropStringAutoGetterSetter,	//  <- UnityEngine.MyClass::get_stringAutoGetterSetter
	(const void*)&MyClass_Set_Custom_PropStringAutoGetterSetter,	//  <- UnityEngine.MyClass::set_stringAutoGetterSetter
	(const void*)&MyClass_CUSTOM_INTERNAL_get_vector3Auto ,	//  <- UnityEngine.MyClass::INTERNAL_get_vector3Auto
	(const void*)&MyClass_CUSTOM_INTERNAL_get_vector3AutoGetterSetter,	//  <- UnityEngine.MyClass::INTERNAL_get_vector3AutoGetterSetter
	(const void*)&MyClass_CUSTOM_INTERNAL_set_vector3AutoGetterSetter,	//  <- UnityEngine.MyClass::INTERNAL_set_vector3AutoGetterSetter
	(const void*)&MyClass_Get_Custom_PropFlarePtr         ,	//  <- UnityEngine.MyClass::get_flarePtr
	(const void*)&MyClass_Set_Custom_PropFlarePtr         ,	//  <- UnityEngine.MyClass::set_flarePtr
	(const void*)&MyClass_Get_Custom_PropFlare            ,	//  <- UnityEngine.MyClass::get_flare
	(const void*)&MyClass_Set_Custom_PropFlare            ,	//  <- UnityEngine.MyClass::set_flare
	(const void*)&MyClass_Get_Custom_PropBoolAutoPtr      ,	//  <- UnityEngine.MyClass::get_boolAutoPtr
	(const void*)&MyClass_Get_Custom_PropBoolAutoGetterSetterPtr,	//  <- UnityEngine.MyClass::get_boolAutoGetterSetterPtr
	(const void*)&MyClass_Set_Custom_PropBoolAutoGetterSetterPtr,	//  <- UnityEngine.MyClass::set_boolAutoGetterSetterPtr
	(const void*)&MyClass_Get_Custom_PropStringAutoPtr    ,	//  <- UnityEngine.MyClass::get_stringAutoPtr
	(const void*)&MyClass_Get_Custom_PropStringAutoGetterSetterPtr,	//  <- UnityEngine.MyClass::get_stringAutoGetterSetterPtr
	(const void*)&MyClass_Set_Custom_PropStringAutoGetterSetterPtr,	//  <- UnityEngine.MyClass::set_stringAutoGetterSetterPtr
	(const void*)&MyClass_Get_Custom_PropVector3AutoPtr   ,	//  <- UnityEngine.MyClass::get_vector3AutoPtr
	(const void*)&MyClass_Get_Custom_PropVector3AutoGetterSetterPtr,	//  <- UnityEngine.MyClass::get_vector3AutoGetterSetterPtr
	(const void*)&MyClass_Set_Custom_PropVector3AutoGetterSetterPtr,	//  <- UnityEngine.MyClass::set_vector3AutoGetterSetterPtr
	(const void*)&MyClass_CUSTOM_intMethod                ,	//  <- UnityEngine.MyClass::intMethod
	(const void*)&MyClass_CUSTOM_stringMethod             ,	//  <- UnityEngine.MyClass::stringMethod
	(const void*)&MyClass_CUSTOM_IntPtrMethod             ,	//  <- UnityEngine.MyClass::IntPtrMethod
	(const void*)&MyClass_CUSTOM_Vector3Method            ,	//  <- UnityEngine.MyClass::Vector3Method
	(const void*)&MyClass_CUSTOM_static_intMethod         ,	//  <- UnityEngine.MyClass::static_intMethod
	(const void*)&MyClass_CUSTOM_private_intMethod        ,	//  <- UnityEngine.MyClass::private_intMethod
	(const void*)&MyClass_CUSTOM_private_static_intMethod ,	//  <- UnityEngine.MyClass::private_static_intMethod
	(const void*)&MyClass_CUSTOM_static_private_intMethod ,	//  <- UnityEngine.MyClass::static_private_intMethod
	(const void*)&MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3,	//  <- UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3
	(const void*)&MyClass_CUSTOM_voidMethodVector3Out     ,	//  <- UnityEngine.MyClass::voidMethodVector3Out
	(const void*)&MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3Ref,	//  <- UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3Ref
	(const void*)&MyClass_CUSTOM_voidMethodVector3OutIntOut,	//  <- UnityEngine.MyClass::voidMethodVector3OutIntOut
	(const void*)&MyClass_CUSTOM_voidMethodVector3OutVector3Out,	//  <- UnityEngine.MyClass::voidMethodVector3OutVector3Out
	(const void*)&MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3RefVector3Ref,	//  <- UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3RefVector3Ref
	(const void*)&MyClass_CUSTOM_voidMethodWritableObject ,	//  <- UnityEngine.MyClass::voidMethodWritableObject
	(const void*)&MyClass_CUSTOM_INTERNAL_CALL_staticvoidMethodVector3,	//  <- UnityEngine.MyClass::INTERNAL_CALL_staticvoidMethodVector3
	(const void*)&MyClass_CUSTOM_StaticVoidMethodStringDef,	//  <- UnityEngine.MyClass::StaticVoidMethodStringDef
	(const void*)&MyClass_CUSTOM_StaticVoidMethodStringStringDef,	//  <- UnityEngine.MyClass::StaticVoidMethodStringStringDef
	(const void*)&MyClass_CUSTOM_StaticVoidMethodStringStringDefStringDef,	//  <- UnityEngine.MyClass::StaticVoidMethodStringStringDefStringDef
	(const void*)&MyClass_CUSTOM_StaticVoidMethodStringStringStringDef,	//  <- UnityEngine.MyClass::StaticVoidMethodStringStringStringDef
	(const void*)&MyClass_CUSTOM_SafeIntPtrMethodIntPtrStringDef,	//  <- UnityEngine.MyClass::SafeIntPtrMethodIntPtrStringDef
	(const void*)&MyClass_CUSTOM_IntPtrMethodIntPtrStringDef,	//  <- UnityEngine.MyClass::IntPtrMethodIntPtrStringDef
	(const void*)&MyClass_CUSTOM_INTERNAL_CALL_SafevoidMethodVector3,	//  <- UnityEngine.MyClass::INTERNAL_CALL_SafevoidMethodVector3
	NULL
};

void ExportTestAllPossibleTypeCombosBindings();
void ExportTestAllPossibleTypeCombosBindings()
{
	for (int i = 0; s_TestAllPossibleTypeCombos_IcallNames [i] != NULL; ++i )
		mono_add_internal_call( s_TestAllPossibleTypeCombos_IcallNames [i], s_TestAllPossibleTypeCombos_IcallFuncs [i] );
}

#elif ENABLE_DOTNET
// This comment is here on purpose, so Jam won't pick WinRTHelper.h as dependency for non WinRT targets, thus not doing unneeded recompilation.
//#include "Runtime/Scripting/WinRTHelper.h"
void ExportTestAllPossibleTypeCombosBindings()
{
	#if UNITY_WP8
	extern intptr_t g_WinRTFuncPtrs[];
	#define SET_METRO_BINDING(Name) g_WinRTFuncPtrs[k##Name##FuncDef] = reinterpret_cast<intptr_t>(Name);
	#else
	long long* p = GetWinRTFuncDefsPointers();
	#define SET_METRO_BINDING(Name) p[k##Name##Func] = (long long)Name;
	#endif
	SET_METRO_BINDING(MyClass_Get_Custom_PropIntPropGetter);	//  <- UnityEngine.MyClass::get_intPropGetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropIntPropGetterSetter);	//  <- UnityEngine.MyClass::get_intPropGetterSetter
	SET_METRO_BINDING(MyClass_Set_Custom_PropIntPropGetterSetter);	//  <- UnityEngine.MyClass::set_intPropGetterSetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropStringPropGetter);	//  <- UnityEngine.MyClass::get_stringPropGetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropStringPropGetterSetter);	//  <- UnityEngine.MyClass::get_stringPropGetterSetter
	SET_METRO_BINDING(MyClass_Set_Custom_PropStringPropGetterSetter);	//  <- UnityEngine.MyClass::set_stringPropGetterSetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropVector3PropGetter);	//  <- UnityEngine.MyClass::get_Vector3PropGetter
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_get_Vector3PropGetterSetter);	//  <- UnityEngine.MyClass::INTERNAL_get_Vector3PropGetterSetter
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_set_Vector3PropGetterSetter);	//  <- UnityEngine.MyClass::INTERNAL_set_Vector3PropGetterSetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropStatic_intPropGetter);	//  <- UnityEngine.MyClass::get_static_intPropGetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropPrivate_intPropGetter);	//  <- UnityEngine.MyClass::get_private_intPropGetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropPrivate_static_intPropGetter);	//  <- UnityEngine.MyClass::get_private_static_intPropGetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropStatic_private_intPropGetter);	//  <- UnityEngine.MyClass::get_static_private_intPropGetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropBoolAuto);	//  <- UnityEngine.MyClass::get_boolAuto
	SET_METRO_BINDING(MyClass_Get_Custom_PropBoolAutoGetterSetter);	//  <- UnityEngine.MyClass::get_boolAutoGetterSetter
	SET_METRO_BINDING(MyClass_Set_Custom_PropBoolAutoGetterSetter);	//  <- UnityEngine.MyClass::set_boolAutoGetterSetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropStringAuto);	//  <- UnityEngine.MyClass::get_stringAuto
	SET_METRO_BINDING(MyClass_Get_Custom_PropStringAutoGetterSetter);	//  <- UnityEngine.MyClass::get_stringAutoGetterSetter
	SET_METRO_BINDING(MyClass_Set_Custom_PropStringAutoGetterSetter);	//  <- UnityEngine.MyClass::set_stringAutoGetterSetter
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_get_vector3Auto);	//  <- UnityEngine.MyClass::INTERNAL_get_vector3Auto
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_get_vector3AutoGetterSetter);	//  <- UnityEngine.MyClass::INTERNAL_get_vector3AutoGetterSetter
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_set_vector3AutoGetterSetter);	//  <- UnityEngine.MyClass::INTERNAL_set_vector3AutoGetterSetter
	SET_METRO_BINDING(MyClass_Get_Custom_PropFlarePtr);	//  <- UnityEngine.MyClass::get_flarePtr
	SET_METRO_BINDING(MyClass_Set_Custom_PropFlarePtr);	//  <- UnityEngine.MyClass::set_flarePtr
	SET_METRO_BINDING(MyClass_Get_Custom_PropFlare);	//  <- UnityEngine.MyClass::get_flare
	SET_METRO_BINDING(MyClass_Set_Custom_PropFlare);	//  <- UnityEngine.MyClass::set_flare
	SET_METRO_BINDING(MyClass_Get_Custom_PropBoolAutoPtr);	//  <- UnityEngine.MyClass::get_boolAutoPtr
	SET_METRO_BINDING(MyClass_Get_Custom_PropBoolAutoGetterSetterPtr);	//  <- UnityEngine.MyClass::get_boolAutoGetterSetterPtr
	SET_METRO_BINDING(MyClass_Set_Custom_PropBoolAutoGetterSetterPtr);	//  <- UnityEngine.MyClass::set_boolAutoGetterSetterPtr
	SET_METRO_BINDING(MyClass_Get_Custom_PropStringAutoPtr);	//  <- UnityEngine.MyClass::get_stringAutoPtr
	SET_METRO_BINDING(MyClass_Get_Custom_PropStringAutoGetterSetterPtr);	//  <- UnityEngine.MyClass::get_stringAutoGetterSetterPtr
	SET_METRO_BINDING(MyClass_Set_Custom_PropStringAutoGetterSetterPtr);	//  <- UnityEngine.MyClass::set_stringAutoGetterSetterPtr
	SET_METRO_BINDING(MyClass_Get_Custom_PropVector3AutoPtr);	//  <- UnityEngine.MyClass::get_vector3AutoPtr
	SET_METRO_BINDING(MyClass_Get_Custom_PropVector3AutoGetterSetterPtr);	//  <- UnityEngine.MyClass::get_vector3AutoGetterSetterPtr
	SET_METRO_BINDING(MyClass_Set_Custom_PropVector3AutoGetterSetterPtr);	//  <- UnityEngine.MyClass::set_vector3AutoGetterSetterPtr
	SET_METRO_BINDING(MyClass_CUSTOM_intMethod);	//  <- UnityEngine.MyClass::intMethod
	SET_METRO_BINDING(MyClass_CUSTOM_stringMethod);	//  <- UnityEngine.MyClass::stringMethod
	SET_METRO_BINDING(MyClass_CUSTOM_IntPtrMethod);	//  <- UnityEngine.MyClass::IntPtrMethod
	SET_METRO_BINDING(MyClass_CUSTOM_Vector3Method);	//  <- UnityEngine.MyClass::Vector3Method
	SET_METRO_BINDING(MyClass_CUSTOM_static_intMethod);	//  <- UnityEngine.MyClass::static_intMethod
	SET_METRO_BINDING(MyClass_CUSTOM_private_intMethod);	//  <- UnityEngine.MyClass::private_intMethod
	SET_METRO_BINDING(MyClass_CUSTOM_private_static_intMethod);	//  <- UnityEngine.MyClass::private_static_intMethod
	SET_METRO_BINDING(MyClass_CUSTOM_static_private_intMethod);	//  <- UnityEngine.MyClass::static_private_intMethod
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3);	//  <- UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3
	SET_METRO_BINDING(MyClass_CUSTOM_voidMethodVector3Out);	//  <- UnityEngine.MyClass::voidMethodVector3Out
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3Ref);	//  <- UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3Ref
	SET_METRO_BINDING(MyClass_CUSTOM_voidMethodVector3OutIntOut);	//  <- UnityEngine.MyClass::voidMethodVector3OutIntOut
	SET_METRO_BINDING(MyClass_CUSTOM_voidMethodVector3OutVector3Out);	//  <- UnityEngine.MyClass::voidMethodVector3OutVector3Out
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_CALL_voidMethodVector3RefVector3Ref);	//  <- UnityEngine.MyClass::INTERNAL_CALL_voidMethodVector3RefVector3Ref
	SET_METRO_BINDING(MyClass_CUSTOM_voidMethodWritableObject);	//  <- UnityEngine.MyClass::voidMethodWritableObject
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_CALL_staticvoidMethodVector3);	//  <- UnityEngine.MyClass::INTERNAL_CALL_staticvoidMethodVector3
	SET_METRO_BINDING(MyClass_CUSTOM_StaticVoidMethodStringDef);	//  <- UnityEngine.MyClass::StaticVoidMethodStringDef
	SET_METRO_BINDING(MyClass_CUSTOM_StaticVoidMethodStringStringDef);	//  <- UnityEngine.MyClass::StaticVoidMethodStringStringDef
	SET_METRO_BINDING(MyClass_CUSTOM_StaticVoidMethodStringStringDefStringDef);	//  <- UnityEngine.MyClass::StaticVoidMethodStringStringDefStringDef
	SET_METRO_BINDING(MyClass_CUSTOM_StaticVoidMethodStringStringStringDef);	//  <- UnityEngine.MyClass::StaticVoidMethodStringStringStringDef
	SET_METRO_BINDING(MyClass_CUSTOM_SafeIntPtrMethodIntPtrStringDef);	//  <- UnityEngine.MyClass::SafeIntPtrMethodIntPtrStringDef
	SET_METRO_BINDING(MyClass_CUSTOM_IntPtrMethodIntPtrStringDef);	//  <- UnityEngine.MyClass::IntPtrMethodIntPtrStringDef
	SET_METRO_BINDING(MyClass_CUSTOM_INTERNAL_CALL_SafevoidMethodVector3);	//  <- UnityEngine.MyClass::INTERNAL_CALL_SafevoidMethodVector3
}

#endif
