using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace UnityEngine
{
[System.Runtime.InteropServices.StructLayout (System.Runtime.InteropServices.LayoutKind.Sequential)]
public struct Matrix4x4
{
		public float m00, m10, m20, m30;
	
	
	#if __MonoCS__
	public extern  bool isIdentity
	{
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		get;
	}

	#else
	public  bool isIdentity
	{
		#if ENABLE_DOTNET
		[WrapperlessIcall ()]
		[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
		#endif
		get {return default(bool);}
	}

	#endif
}

}
