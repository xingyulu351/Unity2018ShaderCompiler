using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
public sealed partial class MyClass
{
	public void EnsureQuaternionContinuity (string arg1, SomethingElse arg2) {
		INTERNAL_CALL_EnsureQuaternionContinuity ( this, arg1, arg2 );
	}

	[WrapperlessIcall ()]
	[System.Runtime.CompilerServices.MethodImplAttribute(System.Runtime.CompilerServices.MethodImplOptions.InternalCall)]
	private extern static void INTERNAL_CALL_EnsureQuaternionContinuity (MyClass self, string arg1, SomethingElse arg2);
}

