using scm=System.ComponentModel;
using uei=UnityEngine.Internal;

using System;
namespace UnityEngine
{
#if UNITY_EDITOR
public sealed partial class Class1 : Behaviour
{
}

#endif
public sealed partial class Class2 : Behaviour
{
}

